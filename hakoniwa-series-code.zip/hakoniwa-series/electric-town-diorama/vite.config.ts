import { defineConfig } from 'vite';

export default defineConfig({
  build: {
    // three.js 本体と、看板の書体（使う文字だけに絞って埋め込み、約 86kB）を含むため 500kB を超える（gzip 後は約 270kB）
    chunkSizeWarningLimit: 900,
  },
});
