import { defineConfig } from 'vite';

export default defineConfig({
  build: {
    // three.js 本体を含むため 500kB を超える（gzip 後は約140kB）
    chunkSizeWarningLimit: 800,
  },
});
