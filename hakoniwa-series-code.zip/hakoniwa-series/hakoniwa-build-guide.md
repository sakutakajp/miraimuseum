# 箱庭シリーズ 制作手順書

別の作業環境でも、これまでと同じ作り・同じ品質で箱庭シリーズの新しい作品を作るための手順書です。
2026 年 10 月 17 日までの 5 作（淡い砂の角丸ミニチュア台座・ニューヨーク・図書館・ジュラ紀の川辺・電気街）で使った進め方、決まりごと、道具をまとめています。

- コード一式：`hakoniwa-series-code.zip`（5 作の最終版と、この手順書。新しい作品はここから近い作品を写して始める）
- この手順書の付録 A に、撮影・比較・カメラ合わせ・配置の確認・1 枚の HTML にまとめる道具のコードがそのまま入っています

---

## 0. 新しい作業での始め方

### 0.1 渡すもの

| 渡すもの | 内容 |
| --- | --- |
| コード一式 | `hakoniwa-series-code.zip`（5 作のフォルダ、全体の README、この手順書） |
| この手順書 | `hakoniwa-build-guide.md`（zip の中にも同じものがある） |
| 参考画像 | 再現したい箱庭の画像。何枚かあるときは、基準にする 1 枚（ふつうは正面寄りのもの）を決めて伝える |

### 0.2 依頼の文の例

```text
「箱庭シリーズ制作手順書」（hakoniwa-build-guide.md）に従って、参考画像（ref/reference.png）を箱庭シリーズの新しい作品にしてください。
- コードは hakoniwa-series-code.zip の作品を土台にする（いちばん近い作品を選ぶ）
- これまでの作品とは別の新しいフォルダ・新しい HTML ファイルとして作る（前の作品のファイルは変えない）
- 縮尺は作品に合わせて変えてよい
- できたら、この作品で分かったことを手順書の 6 章・8 章に追記する
```

### 0.3 最初にすること

1. この手順書を最後まで読む（とくに 1.1 の方針、2 章の決まりごと、6 章の中身の種類ごとの要点）
2. `hakoniwa-series-code.zip` を作業フォルダに展開し、全体の `README.md` を読む
3. 付録 A の道具を `tools/` に保存する（5〜7 章の手順はこの道具を使う）
4. 参考画像を見て、土台にする作品を選ぶ（5.2）。作業の段階（4 章の表）を一覧にして、終わった所から消していく

---

## 1. 箱庭シリーズとは

暖かいベージュの床の上に、四隅の丸い正方形の台座が置かれ、その上に小さな世界が載っている、ミニチュア模型のような 3D の箱庭です。
Three.js で描き、ブラウザでドラッグして好きな向きから眺められます。台座・床・光・カメラ・画面の作りは全作で同じで、違うのは台座の上の中身だけです。

| # | 作品 | フォルダ | 台座の上 | 中身のコード |
| --- | --- | --- | --- | --- |
| 1 | 淡い砂の角丸ミニチュア台座 | `sand-pedestal` | 透明な水の塊と C 字形の島 | `src/island/`・`src/sea/`・`src/rocks/`・`src/vegetation/` |
| 2 | ニューヨークの箱庭 | `nyc-diorama` | 水の塊に浮かぶ街と橋 | `src/buildings.ts`・`src/bridge.ts`・`src/layout.ts`・`src/sea/` |
| 3 | 図書館の箱庭 | `library-diorama` | 大理石の台の上の室内 | `src/room/` |
| 4 | ジュラ紀の川辺の箱庭 | `dino-diorama` | 地面の塊と川の断面 | `src/terrain/`・`src/river/`・`src/plants/`・`src/rocks/` |
| 5 | 電気街の箱庭 | `electric-town-diorama` | 路面の塊の上の街 | `src/town/` |

### 1.1 依頼者の方針（毎回守る）

- **シリーズにそろえる**：台座・床・光・カメラ・画面は 2 章の値のまま。違うのは中身だけ
- **作品ごとに別のページ**：新しい作品は新しいフォルダと新しい 1 枚の HTML にする（前の作品のファイルを上書きしない）
- **縮尺は作品ごとに決めてよい**：台座の一辺 10 が何 m かは中身に合わせる（例：電気街は 1 単位がおよそ 4 m）
- **外部の画像素材を使わない**：形・模様・看板の絵・影は、起動時にプログラムで生成する（書体だけは OFL の書体を埋め込んでよい）
- **実在の店名・ロゴ・キャラクターを使わない**：看板や商品は架空のもの。名前とロゴも自作する
- **現実にありえる形にする**：道の幅は一定、建物は長方形で必ず道に面する、など（6.2）。参考画像に似せるより先に、上から見て成り立つかを確かめる
- **報告には比較画像を付ける**：参考画像と今回を同じ大きさで並べた画像、注目する所の拡大、直す前と直した後
- **日本語で**：やりとり・README・コードのコメントは日本語
- **最後に知見を残す**：この作品で分かったことを、この手順書の 6 章・8 章に追記する（5.11）

---

## 2. シリーズの共通仕様（変えない値）

値はどの作品も `src/config.ts` の前半にあります。新しい作品でもこのまま写します。長さはワールド座標で、台座の一辺が 10、中心が原点、x は画面の右、z は手前、y は床が 0（土台の上面が 0.255）です。

| 項目 | 値 | 設定・ファイル |
| --- | --- | --- |
| 台座 | 一辺 10 の正方形、四隅の半径 1.2。上縁の丸み 0.07、下縁の丸み 0.03 | `config.pedestal`、`src/pedestal.ts` |
| 木地の土台 | 厚さ 0.255、色 `#a58c6a`、粗さ 0.42。台座の塊より一辺の 1.2% 内側（`0.012 × 10`） | `config.pedestal`、`main.ts` の `baseInset` |
| 床 | `#e2d6cf`、明るさの傾き 0.18（方位 45°・距離 14）、台座の影（強さ 0.38、ずれ (−0.12, 0.13)、ぼかし 0.075） | `config.floor`、`src/floor.ts` |
| 背景 | `#fae8d4`（トーンマッピングの逆を通して、画面でこの色に見えるようにする） | `config.renderer.background`、`main.ts` の `untoned()` |
| 主光 | `#fff5e4`、強さ 3.9、方位 35°、仰角 40°、広がり 18° | `config.lights.key` |
| 補助光 | `#fff1df`、強さ 1.4、方位 150°、仰角 48°、広がり 25° | `config.lights.fill` |
| 半球光 | 空 `#fdf0e2`・床 `#f3d6b5`、強さ 0.8、床側 ×2.2 | `config.lights.ambient` |
| 影の焼き込み | 光のサンプル 64、空の遮蔽 96（仰角 7° 以上）、影の地図 2048、焼き込み 1024。起動時に 1 回だけ（重い中身の作品は 40・64 に減らしてよい） | `config.shadow`、`src/lightBaker.ts`、`src/bakedLighting.ts` |
| 軽い設定 | GPU のない環境：光 28・遮蔽 36・焼き込み 512・影の地図 1024・画素比 1（形と配置は同じ） | `config.lowPower`、`?quality=low` |
| 仕上げ | 明るさ 0.9 より上だけを丸めるトーンマッピング、露出 1、画素比は 2 まで | `config.renderer`、`src/toneMapping.ts` |
| カメラ | 仰角 22.8°、画角 13.44°、距離 48.6（一辺の 4.86 倍）、注視点の高さは土台の上面から一辺の 0.165 倍 | `config.camera` |
| 構図 | 台座の外形と中身の上端が余白に収まるように、画角とレンズのずらし（`setViewOffset`）で決める | `config.framing`、`config.framingOther`、`src/framing.ts` |
| 操作 | ドラッグで回転（仰角 8〜88°）、ホイール・ピンチで拡大（0.6〜3.5 倍）、右ドラッグ・2 本指で平行移動、ダブルクリック・0 キーで元の向き。惰性は上限付き | `config.controls`、`src/viewControls.ts` |
| 画面 | 背景 `#fae8d4`、案内文の焦げ茶 `#6b4f3a`、最初の 1 回だけ下に出る操作の案内、3D を始められないときの案内文 | `index.html`、`src/style.css` |

作品ごとに変えてよいのは次の所だけです。

- **カメラの方位と注視点の高さ**：参考画像に合わせて求める（5.3）。例：電気街 −9°、図書館 22°・注視点 0.22
- **構図の余白**（`config.framing` の `paddingTop` など）：参考画像の構図に合わせる
- **台座の上の塊**：水の塊（1・2）、大理石の台（3）、地面の塊（4）、路面の塊（5）。外形は台座と同じ角丸の正方形
- **中身の色調**：シリーズの光の向きと強さは変えず、中身の物にだけ色調を掛ける（例：電気街の夕方の色調）

---

## 3. 作業環境

| 道具 | 使い方 |
| --- | --- |
| Node.js 20.19 以上（または 22.12 以上） | 各作品のフォルダで `npm install`、`npm run dev`、`npm run build`（`tsc --noEmit` と `vite build`） |
| Three.js r186（`three@^0.186.1`）・TypeScript（strict）・Vite 8 | 各作品の `package.json` のまま |
| Python 3 と Playwright（Chromium） | 自動撮影。GPU がなくても `--use-angle=swiftshader` で WebGL を描ける |
| Pillow・NumPy・SciPy・Shapely | 比較画像、カメラ合わせ、平面の確認 |
| fonttools・brotli | 書体を使う文字だけに絞る（看板の文字を描くとき） |

```bash
pip install --break-system-packages playwright pillow numpy scipy shapely fonttools brotli
# Chromium は作業環境に入っていることが多い（PLAYWRIGHT_BROWSERS_PATH）。入っていないときだけ:
# python3 -m playwright install chromium
```

- ネットワークは npm・pip・GitHub くらいしか通らないことが多い。書体は `https://raw.githubusercontent.com/google/fonts/main/ofl/<名前>/<ファイル>` から取れる（`github.com/.../raw/...` は通らないことがある）
- 撮影はソフトウェア描画なので遅い。配置を見るだけなら `?quality=low&bake=0`（影の焼き込みを省く。電気街のみ）や `?quality=low`、仕上がりは `?quality=high`
- 作業フォルダの例：`~/hakoniwa/<作品のフォルダ>`、道具は `~/hakoniwa/tools/`、撮った画像は `~/hakoniwa/shots/`（以下の例は `~/hakoniwa` で実行する）

---

## 4. 全体の流れ

| 段階 | すること | できるもの |
| --- | --- | --- |
| 1 | 参考画像を読み、中身・縮尺・土台にする作品を決める | 方針（中身の一覧、縮尺、参考画像の基準の 1 枚） |
| 2 | 土台の作品を写して新しいプロジェクトにする | 動く空の箱庭（台座・床・光・カメラ） |
| 3 | カメラを参考画像に合わせる | `fit.json`、`config.camera.azimuth`、`?refcam` |
| 4 | 中身を上から見た平面で決め、自動で確かめる | 平面の図（道・建物・水・物の位置） |
| 5 | 3D で作る（形・質感・小物） | 中身のモジュール |
| 6 | 光・影・色調を合わせる | 焼き込んだ影、色調 |
| 7 | 撮って参考画像と比べ、直す（何度も回す） | 比較画像、向きを変えた画像 |
| 8 | 操作・負荷・スマートフォンの幅を確かめる | 確認の画像 |
| 9 | そのまま開ける 1 枚の HTML にまとめる | `〇〇の箱庭.html` |
| 10 | zip・HTML・画像・短い報告を渡す | 依頼者に渡すもの |
| 11 | 分かったことを手順書に追記する | 手順書の更新 |

いちばん効くのは「撮って、測って、並べる」ことです。見た目の違いを数値や並べた画像で確かめてから直すと、手戻りが減ります。

---

## 5. 各段階の詳しい手順

### 5.1 参考画像を読む

- **基準の 1 枚を決める**：何枚かある参考画像は、物の大きさや位置が少しずつ食い違う。正面寄りの 1 枚を基準にし、どの向きから見ても同じ 1 つの形にする
- **共通の所と中身を分ける**：台座・床・背景・光はシリーズの値で作るので、参考画像の色に合わせない。合わせるのは台座の上の中身
- **中身を一覧にする**：大きな形（島・建物・部屋・川）→ 中くらいの物（木・岩・看板・家具）→ 小物（人・車・街灯）の順に書き出す
- **縮尺を決める**：人や扉の大きさから、1 単位が何 m かを決める（例：電気街は人の背 0.44、1 単位 ≒ 4 m）
- **現実に成り立つかを先に考える**：参考画像の見た目をなぞると、上から見て成り立たない形になりやすい（道の幅が場所で変わる、建物が台形、入口のない建物）。6 章の決まりで作り直す前提で読む

### 5.2 土台にする作品を選んで写す

| 新しい作品の中身 | 土台にする作品 | 理由 |
| --- | --- | --- |
| 海・湖に浮かぶ島や街 | `sand-pedestal`・`nyc-diorama` | 透明な水の塊、水の色の計算、砂、海底 |
| 川・滝・地形・森 | `dino-diorama` | 地面の塊の切り口、川の断面、植物のひな形 |
| 部屋・建物の中 | `library-diorama` | 台の上の室内、窓の光の筋、家具 |
| 街・通り・夜景・看板 | `electric-town-diorama` | 路面の塊、建物の外壁のシェーダー、看板、街の明かり、濡れた路面 |

写したら、次の所を新しい作品の名前に変えます。

1. フォルダ名と `package.json` の `name`
2. `index.html` の `<title>` と、キャンバスの `aria-label`（何が見えるかを日本語で具体的に）
3. `src/main.ts` の `HINT_KEY`（操作の案内を一度見たかの印。`'<作品>:view-hint-seen'`）
4. `README.md`（作品の説明・動かし方・操作・確認用の URL パラメータ・共通仕様・作りのあらまし）
5. `src/config.ts` の後半（中身の値）。前半はそのまま
6. 中身のモジュール（`src/island/`・`src/town/` など）は、新しい中身のものに置き換える。共通のファイル（2 章の表）は変えない

`npm install` → `npx tsc --noEmit` → 撮影（7 章）で、空の箱庭がシリーズと同じ見た目で出ることを先に確かめます。

### 5.3 カメラを参考画像に合わせる

参考画像の台座の外形に、シリーズのカメラを合わせます。仰角・距離・注視点の高さはシリーズの値に固定し、方位と焦点距離と画像の中心を求めます。

1. 参考画像を作業フォルダに置く（例：`ref/reference.png`）
2. 土台（木地の帯）の上端と下端を列ごとに拾う：
   `python3 tools/pick_outline.py ref/reference.png ref/obs.json --ymin <帯が写る範囲の上> --ymax <下>`
   `ref/obs_check.png` で、帯の上下の縁に赤い点が並んでいるかを見る。拾えないときは、色のしきい値（`plate = ...` の行）を画像に合わせる
3. カメラを求める：`python3 tools/fit_camera.py ref/obs.json ref/reference.png ref/fit.json`
   rms が数画素なら合っている。`ref/fit_check.png` で、紫（床の縁）と緑（土台の上端）が帯に重なるかを見る
4. 方位 `az` を丸めて `config.camera.azimuth` に入れる（例：−8.8 → −9）。注視点の高さは中身が高いときだけ変える
5. `main.ts` に `?refcam`（付録 A-11）を入れ、`fit.json` の値（az・f・cx・cy・画像の大きさ）を書く。以後の参考画像との比較はすべて `?refcam=1` で、参考画像と同じ大きさで撮る
6. 既定の向きの構図（`config.framing`）は、`?refcam` を付けない画面が参考画像の構図に近くなるように余白を決める

参考画像の点を 3D の位置に直すときは `tools/backproject.py`（付録 A-8）を使います。たとえば建物の足もとや岩の中心を参考画像で拾い、地面の高さの面に戻して平面の座標にします。参考画像の物の高さが今回と違うときは、割合で写し直してから戻します。

### 5.4 中身を上から見た平面で決める

3D を作る前に、上から見た平面の図で配置を決めます。電気街では、参考画像の見た目をなぞった配置を「道の幅がありえない・建物が四角形でない・入口がない」と指摘され、平面から作り直しました。

- **座標**：台座の中心が原点、一辺 10。中身は台座の縁から一辺の 1.2% 以上（0.12）離す（縁で切った切り口を作らない）
- **枠（フレーム）で書く**：道や川など、物がそろう向きの線を「点と向き」で決め、その線に沿った長さ s と、線から奥への距離 d で物を置く（電気街の `src/town/plan.ts` の `L(s, d)`・`R(s, d)`・`A(s, d)`）
- **街なら `tools/check_plan.py`（付録 A-5）**：通り・歩道・路地・裏路地・広場と長方形の建物を `plan.json` に書くと、重なり・台座の縁・入口の面が道につながるかを調べて図にする。`OK` が出るまで直す
- **水や地形なら**：水深・岩の位置などを、プロジェクトのモジュールを Node で直接動かして上から見た地図に書き出すと、描かずに数秒で確かめられる（`npx rolldown <確認用の ts> --file out.mjs --platform node` → `node out.mjs`）

### 5.5 3D で作る

- **すべてコードで生成する**：形は関数・距離・ノイズから作り、模様や絵はキャンバスに描いてテクスチャにする。外部の画像は使わない
- **中身は 1 つのグループに**：地面の高さにグループを置き、その中は地面を 0 とした座標で作る
- **同じ形はまとめて描く**：木・岩・人・小物はひな形を数種類作り、`InstancedMesh` か、まとめた 1 つの形にして描く（描画の回数を減らす）
- **建物の外壁は 1 つのシェーダー**：タイル・汚れ・窓・窓の奥の部屋（interior mapping）・店先を面の座標から描く（電気街の `src/town/buildings.ts`）
- **細部は少しずつ足す**：大きな形 → 中くらいの物 → 小物の順に、1 段ごとに撮って確かめる
- **確認用の URL パラメータを用意する**：中身の一部を隠す（`?rocks=0`、`?sea=0`、`?town=0`）、動きを止める（`?seaTime=3`、`?waterTime=3`）、配置の確認（`?debug=mass`）など。色の問題か形の問題かを切り分けられる

### 5.6 光・影・色調

- **シリーズの光を崩さない**：主光・補助光・半球光の向きと強さは 2 章の値。中身の拡散光は半球光から受ける
- **影は焼き込む**：影と空からの遮蔽は起動時に 1 回だけ計算する（`lightBaker.ts`）。床・地面は平面の焼き込み、建物の壁は面ごとの光の地図、小物は 1 つにつき 1 点（その点は物の中ではなく、物の上に置く。中に置くと真っ黒になる）
- **つやのある面だけ映り込み用の空**：ガラス・車・水面など
- **色調は中身にだけ**：夕方なら、日差しに暖色、空からの光に青を掛ける（電気街の `config.town.tint`）。床・台座・背景の色は変えない
- **明かり（夜景）**：店先・街灯・看板の灯りを上から見た HDR の地図 1 枚にまとめ、地面と壁の低い所で読む。店先は点ではなく間口に沿った線の光にする（電気街の `src/town/localLight.ts`）

### 5.7 撮って比べる（毎回の確認）

付録 A の道具で、毎回同じ条件で撮ります。開発サーバーは撮影用に「ファイルを変えても読み直さない」設定で立てます（`tools/devserver.sh`）。

```bash
P=$HOME/hakoniwa/my-diorama; S=$HOME/hakoniwa/shots; mkdir -p $S
# 参考画像のカメラで撮る（参考画像と同じ大きさ。例は 1254×1254）
tools/devserver.sh $P 5181 python3 tools/shot.py "http://127.0.0.1:5181/?hint=0&quality=high&refcam=1" $S/v1_ref.png --size 1254x1254
# 参考画像と並べる・拡大して比べる
python3 tools/compare.py ref/reference.png $S/v1_ref.png $S/v1_sbs.png --labels 参考画像 今回
python3 tools/compare.py ref/reference.png $S/v1_ref.png $S/v1_zoom.png --labels 参考画像 今回 --crop 400,300,900,750 --width 800
# 1 回の読み込みで向きを変えて何枚も撮る（影の焼き込みは 1 回で済む）
tools/devserver.sh $P 5181 python3 tools/views.py "http://127.0.0.1:5181/?hint=0&quality=low" $S/v1 top=0,88 back=180,30 right=80,26 left=-80,26 low=20,8
```

- **毎回撮る向き**：参考画像のカメラ、既定の向き、真上、後ろ、左右、低い角度。正面では見えない不具合（濁り・すき間・浮いた物）は、ほかの向きで見つかる
- **画素で測る**：色は明・中・暗の中央値と R/G・B/G の比、表示・非表示の差分で物だけの画素、縦の色の断面（同じ列の高さごとの中央値）
- **原因を切り分けてから直す**：一部を隠して比べ、形の問題か色の問題かを先に確かめる
- **撮影の注意**：撮影は動きを減らす設定（`reduced_motion`）で行う（水の動きが止まり、毎回同じ画像になる）。準備の目印は `#scene[data-ready="true"]`。準備が終わらないときは、`tools/shot.py` が表示するページのエラー（例：看板のキャンバスに収まらない）を見て直す

### 5.8 操作・負荷・画面の幅を確かめる

- 4 方向と真上に回しても、台座が伸び縮みせず、全体が画面に収まる（元の向きから離れるほど全方位の構図へ移る）
- スマートフォンの幅（390×844 など）で撮り、操作の案内が画面の幅いっぱいの中央に出るか、文字が切れないか
- GPU のない環境（`?quality=low` またはソフトウェア描画）でも同じ形で出るか。起動の時間（コンソールの `scene ready: total … ms`）を見る
- 動いている間だけ解像度を下げ、止まったら元に戻すこと、ページが隠れている間は描かないこと（共通の `main.ts` のまま）

### 5.9 1 枚の HTML にまとめる

作品は、そのまま開ける 1 枚の HTML ファイルにまとめて渡します。コード・書体・画面の CSS はすべてファイルに入れ、three.js だけ CDN（`cdn.jsdelivr.net/npm/three@0.186.1`）から読みます。
`--bundle-three` を付けると three.js もファイルに入り、ネットワークなしで開けます（ネットワークのない環境で確かめるときもこちら）。

```bash
python3 tools/build_single_html.py my-diorama "〇〇の箱庭" dist/my-diorama.html
python3 tools/build_single_html.py my-diorama "〇〇の箱庭" dist-offline/my-diorama.html --bundle-three
# 確かめる：フォルダごとサーバーで開いて撮る（file:// で開くとモジュールの読み込みが止められることがある）
python3 -m http.server 5184 --bind 127.0.0.1 --directory dist-offline &
python3 tools/shot.py "http://127.0.0.1:5184/my-diorama.html?hint=0&quality=high" shots/single.png --size 1600x1200
```

- `<title>` は作品名（例：「電気街の箱庭」）。ファイル名も作品ごとに新しくする（前の作品のファイルを上書きしない）
- 大きさの目安：three.js を CDN から読むと 0.3〜0.4MB、ファイルに入れると約 1MB
- 外から読むのは three.js だけ。画像・書体・データを外から読まない（書体は埋め込む）

### 5.10 渡すもの

| 渡すもの | 作り方 |
| --- | --- |
| プロジェクトの zip | `zip -r <作品>.zip <作品> -x '<作品>/node_modules/*' '<作品>/dist/*'` |
| 1 枚の HTML | 5.9 の出力（CDN 版と、必要ならネットワークなし版） |
| 既定の向きの画像 | 1600×1200、`?quality=high`（まとめた HTML と同じ見え方） |
| 参考画像との比較 | 参考画像と `?refcam=1` の画像を並べたもの（2000 幅くらい） |
| 直す前と直した後 | 修正の依頼に応えたとき。同じ向き・同じ大きさで並べる |
| 短い報告 | 何を作ったか・何を直したか、比較画像の見どころ、気になる残りの点。日本語 |

### 5.11 分かったことを手順書に追記する

作品を仕上げたら、次の作品のために、この手順書に分かったことを足します。

- 6 章：その種類の作品の要点（新しい種類なら `6.5` のように節を足す）。数値は具体的に（例：「車道の幅 2.3」）
- 8 章：よくあるつまずきの表に、`症状・原因・対処` を 1 行ずつ
- 新しく作った道具は付録 A に。作品のフォルダの README にも、その作品で決めたこと（縮尺・枠・お店の表など）を書く
- 直す前と直した後の比較画像は作品のフォルダ（例：`docs/`）に置き、README から参照する

---

## 6. 中身の種類ごとの要点

### 6.1 水の塊の作品（海・湖・川）

- **水の色は塗らずに計算する**：光が水を通る距離 d から吸収と散乱を計算する。`C = C_底 · e^{−(σa+σs)d} + C_水 · (1 − e^{−σs·d})`。吸収は赤・緑・青で 9 : 0.66 : 0.52（赤から失われ、深いほど青い）
- **シリーズの水の色**：浅い所の淡いエメラルド `#a9eee6` → ターコイズ `#03aeb2` → 深い所の青 `#06507f`、透明度 0.25。水の塊の厚さは土台の上から 2.18
- **1 コマの描き方**：不透明な物を色と奥行きの画像に 1 回描き（向きが変わるまで描き直さない）、水面と側面のシェーダーがそれを読む（屈折のずらし、奥行きから d、上の式、空の映り込み・きらめき・泡）
- **深い所は「見かけの水深」を足す**：形は変えず、深い所らしさ（0〜1 のマスク）の 2 乗に比例させる。マスクはぼかし・ゆらぎ・仕上げのぼかしの 3 段
- **側面はガラスのすぐ奥ほど澄ませる**：見通す距離を d² / (d + 定数) で数える。縦のグラデーションは色を混ぜず、水面の近くほど d を足す
- **側面の映り込みは水面の 4 分の 1**（強いと水面の近くが白っぽく浮く）
- **中身は水の塊の中に収める**：島の土台は台座の縁から離す（水面のすぐ下で一辺の 3.5%、底で 9%）。ガラスに張り付くと、低い角度から側面が濁る
- **水の中の土台に「印」**：色の画像のアルファを 0 にして描き、側面ではそれを読んで水の色に沈める（画像を増やさずに物の種類を見分ける）。小石などに印を付けない
- **底の起伏**：浅い所から「島の中を通らない距離」（格子のダイクストラ法、`Float64Array`）で斜面を作り、等深線を円弧にしない（場所ごとにノイズで長さを変える）
- **岩は参考画像から 1 つずつ置く**：等間隔の群れは作り物に見える。画像の点を底に戻して置き、高さの 4〜5 割を砂に埋め、根元に砂をかけ、小石を散らす。台座の縁の近く・崖の真下には置かない
- **水の動き**：1 秒 30 回まで（ソフトウェア描画では 2 回）。`?seaTime=3`・`?waterTime=3` で止められるようにする
- 街を水に浮かべるとき（ニューヨーク）：島は台座の縁で切らず、まわりを水に。高い塔は「選択的圧縮」で高さだけ 0.82 倍。水面の高さにも影を焼き込み、水面の日陰はそれで読む

### 6.2 街の作品

上から見て街として成り立つことを、参考画像に似せることより先にします。

- **車道の幅は一定**：縁石から向かいの縁石まで一定の幅（電気街は 2.3 ＝ 2 車線と路側帯）。その先は向かいの歩道。中央の破線は幅のちょうど真ん中、外側線は両側の縁石から同じ距離（0.25）。交差点の手前に停止線、横断歩道は縁石に沿った位置で
- **建物はすべて長方形**：面している道の枠で、道に沿った範囲 s と奥行き d を決める。見えている屋上の角をなぞった台形・五角形にしない
- **どの建物も道に面する**：通り・広場・路地・裏路地のどれかに、入口のある面（面 0）を向ける。奥の建物のために裏路地を足し、路地は突き当たりの建物まで通す。`tools/check_plan.py` で確かめる
- **歩道の幅をそろえる**：通りに面する建物の正面は、歩道の幅の線にそろえる
- **人は歩ける所だけに**：歩道・向かいの歩道・広場・路地・裏路地の中に置く（建物に囲まれた中庭には置かない）
- **車は通行の向きに**：日本は左側通行。車は自分の車線の真ん中に、走る向きに合わせて置く
- **看板はお店ごと**：架空のお店を作り（名前・短い名前・英字の添え書き・書体・色・ロゴ）、建物ごとに何階に何が入るかを決める
  - 1 階：店先の上の横長の看板（日よけがあれば日よけの上、なければ店先の帯に重ねる）と、お店の色の日よけ
  - 上の階：店名と階（「2F」など）を書いた袖看板。路地では建物の角に、下の階から順に縦に並べる
  - 大きな縦長の看板：上にお店のロゴ、下に売り物の絵記号。ネオンの帯は縦書きの店名
  - 同じお店の看板は、店先と袖看板で色と書体をそろえる。小さな袖看板は短い名前にする
  - 実在の店名・ロゴ・キャラクターは使わない。ロゴはキャンバスの図形で自作する（電気街の `src/town/brands.ts` の `drawEmblem`）
- **看板の文字は埋め込みの書体で**：OFL の書体を Google Fonts のリポジトリから取り、使う文字だけに絞って埋め込む（付録 A-10）。書体を読み込んでから街を作る（看板の絵は最初に 1 回だけ描く）。細い書体は同じ色の縁取りで少し太らせる。縦書きは長音記号を縦の線に、小さな仮名を右上に
- **看板の絵は 1 枚のキャンバスに**：背の高い順に棚に詰め、入らなければキャンバスを縦に倍にする（収まらないと例外で起動しない）
- **夜景・夕景**：窓の奥の部屋の明かり、明るい店先、濡れた路面の映り込み（路面の高さを鏡にしたカメラ。見る向きが変わったときだけ描き直し、明るい所だけ縦に引き伸ばす）、光のにじみ（ブルーム）。店先・棚の光る帯は強すぎると白く飛ぶ

電気街の数値の例：車道の幅 2.3、歩道 0.95・0.7、路地の幅 0.9、裏路地 0.55、1 階の高さ 0.66、上の階 0.6、窓の間隔 0.5、人の背 0.44、看板の絵は 1 単位 300 画素。

### 6.3 室内・台の作品（図書館）

- 壁は奥と左だけにして、手前と右を開けた切り取りにする（中が見える）。奥の左の角は台座と同じ丸みで曲げる
- 本・木目・大理石の床・金文字・絨毯の模様はシェーダーやキャンバスで描く（本は装丁の種類をシェーダーで描き分けて約 2,100 冊）
- 窓からの光の筋は、淡い光の柱（`src/room/sunbeams.ts`）と、床や家具に落ちる窓の形の光で表す
- 注視点の高さ・構図の余白は、高い部屋に合わせて変える（図書館は注視点 0.22、方位 22°）

### 6.4 地形と川の作品（川辺の森）

- 地面の塊の上面は地形、切り口は表土と岩の層を、外周に沿って継ぎ目なく続ける
- 川は中心線に沿って並べた円（左右で半径が違う）を重ねた形にすると、曲がり角でも岸や川底に段ができない。切り口を横切る所はガラスのような水の断面にする
- 植物はひな形（アラウカリア・マツ・広葉樹・ソテツ・シダ）を作って配置し、林の中に低い植物を置かない、川岸から木を離す、など置き方の決まりを作る
- 後から別の 3D モデル（恐竜など）を置く場所は、位置と大きさを設定に残し、木や下草を置かずに空けておく

---

## 7. 仕上げの確認

- [ ] `npm run build`（型チェックと本番ビルド）が通る
- [ ] 参考画像のカメラで撮って並べ、中身の位置・大きさ・色の違いを説明できる
- [ ] 既定の向き・4 方向・真上・低い角度・スマートフォンの幅で、崩れや浮き・すき間・入れない建物がない
- [ ] 台座・床・背景・光・カメラがシリーズの値のまま（既定の向きで前の作品と並べて、台座の大きさ・床の色が同じに見える）
- [ ] 外部の画像素材を使っていない。実在の店名・ロゴ・キャラクターがない。書体は OFL で、ライセンスの全文をプロジェクトに入れた
- [ ] まとめた HTML をサーバーで開いて撮り、起動できる（エラーがない）
- [ ] 新しいフォルダ・新しいファイル名で作った（前の作品のファイルを上書きしていない）
- [ ] zip・HTML・画像・報告を渡した。分かったことを手順書に追記した

---

## 8. よくあるつまずき

| 症状 | 原因 | 対処 |
| --- | --- | --- |
| 低い角度から見ると水の側面が濁った茶色 | 水の中の島の土台がガラスに張り付いていた | 土台を縁から離し、アルファの印で水の色に沈める |
| 側面の上の方が白っぽい | ガラスの映り込みが強すぎた | 側面だけ映り込みを水面の 4 分の 1 に |
| 側面越しの砂が明るすぎる | 水の色を足し算で重ねていた | 混ぜ合わせと色の掛け算に |
| 水面が全体に濃紺 | 深い所らしさが手前のガラスまで続く | 深い所らしさを島からの距離で決め、手前の縁に近い所は弱める |
| 高い建物の影が水面でずれる | 水面の日陰を深い底の焼き込みから読んでいた | 水面の高さにも影を焼き込む |
| 高い塔のせいで台座が小さく写る | 構図が塔の上端を収めるように全体を縮める | 塔の高さだけ縮める（選択的圧縮、0.82 倍） |
| 外壁の足もとの暗さが効かない | 高さをワールドの高さで測っていた | 地面の高さを引いた高さで測る |
| 小物が真っ黒 | 影を焼く点が物の中にあった | 点を物の上に置く |
| 店の前の歩道の真ん中が暗い | 店先の明かりを点で置いた | 間口に沿った線の光に |
| 店先と棚が白く飛ぶ | 光る帯と光のにじみが重なった | 帯の光を弱める（棚 0.3、商品 0.05、店先 1.45） |
| 看板を増やしたら起動しない | 看板の絵がキャンバスに収まらず例外 | 背の高い順に詰め、入らなければ縦に倍 |
| 看板の店名が読めない | 細い書体、小さな袖看板に長い名前 | 縁取りで太らせる、短い名前にする |
| 道路・建物が「現実にありえない」 | 参考画像の見た目をなぞった | 6.2 の決まりで、平面から作り直す |
| 人が中庭に立つ | 歩道の高さならどこでも置いた | 歩ける所の中だけに置く |
| 強くはじくと回りすぎる | 惰性の速さに上限がない | 上限と強めの減衰 |
| スマートフォンで操作の案内が半分の幅 | `left: 50%` と `translateX(-50%)` | `left: 0; right: 0; margin: 0 auto; width: fit-content` |
| 自動撮影がタイムアウト | 描き続けて画面が落ち着かない | 動きを減らす設定で撮る、`?seaTime`・`?waterTime` で止める |
| 撮影中にページが読み直される | 開発サーバーがファイルの変更で読み直す | 撮影用に `hmr: false` のサーバーを別に立てる（`tools/devserver.sh`） |
| 撮影で起動しない（準備の印が付かない） | ページの中で例外が出ている | 画面の案内文とコンソールのエラーを見る（`tools/shot.py` が表示する） |
| `pkill -f` で自分のシェルまで止まる | パターンが自分のコマンドにも一致した | `pkill -f "[h]ttp.server 5184"` のように 1 文字を [ ] で囲む |

---

## 付録 A：道具のコード

ここのコードを、そのまま `tools/` に保存して使います（`chmod +x tools/devserver.sh`）。どれも 5 作で使った道具を、作品によらず使えるように整えたもので、電気街とジュラ紀の川辺で動くことを確かめています。

### A-1 撮影用の開発サーバー（`tools/devserver.sh`）

```bash
#!/bin/bash
# 撮影用の開発サーバーを立てて、引数のコマンドを実行し、終わったら止める。
# ファイルを変えても撮影中のページを読み直さない（hmr: false）。
# usage: tools/devserver.sh <プロジェクトのフォルダ> <ポート> <コマンド...>
#   例: tools/devserver.sh "$PWD/my-diorama" 5181 python3 tools/shot.py "http://127.0.0.1:5181/?hint=0" out.png
set -u
PROJECT=$(cd "$1" && pwd); PORT=$2; shift 2
CFG="$PROJECT/.vite-shots.config.mjs"
cat > "$CFG" <<CONF
export default { root: '$PROJECT', logLevel: 'warn', server: { hmr: false, port: $PORT, strictPort: true, host: '127.0.0.1' } };
CONF
(cd "$PROJECT" && exec npx vite --config "$CFG" > "/tmp/devserver_$PORT.log" 2>&1) &
for i in $(seq 1 120); do curl -s -o /dev/null "http://127.0.0.1:$PORT/" && break; sleep 0.5; done
"$@"
STATUS=$?
pkill -f "vite --config $CFG" 2>/dev/null
rm -f "$CFG"
exit $STATUS
```

### A-2 1 枚撮る（`tools/shot.py`）

```python
"""ページを開き、描画の準備（#scene[data-ready="true"]）を待って撮る。GPU のない環境でも SwiftShader で WebGL を描く。
usage: python3 tools/shot.py URL OUT.png [--size 1600x1200] [--dpr 1] [--wait 1500]
  URL の例: http://127.0.0.1:5181/?hint=0&quality=high
"""
import argparse, sys, time
from playwright.sync_api import sync_playwright

FLAGS = ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--enable-webgl', '--hide-scrollbars']
ap = argparse.ArgumentParser()
ap.add_argument('url'); ap.add_argument('out')
ap.add_argument('--size', default='1600x1200'); ap.add_argument('--dpr', type=float, default=1); ap.add_argument('--wait', type=int, default=1500)
a = ap.parse_args()
w, h = (int(v) for v in a.size.split('x'))
t0 = time.time()
with sync_playwright() as pw:
    b = pw.chromium.launch(args=FLAGS)
    # 動きを減らす設定：水の動きなどが止まり、毎回同じ画像になる（撮影も速い）
    pg = b.new_page(viewport={'width': w, 'height': h}, device_scale_factor=a.dpr, reduced_motion='reduce')
    logs = []
    pg.on('console', lambda m: logs.append(f'[{m.type}] {m.text}'))
    pg.on('pageerror', lambda e: logs.append(f'[pageerror] {e}'))
    pg.goto(a.url, wait_until='commit', timeout=600000)
    try:
        pg.wait_for_selector('#scene[data-ready="true"]', timeout=900000)
    except Exception:
        print('準備が終わらなかった:', pg.evaluate("document.getElementById('scene-message')?.textContent || ''"))
        for l in logs: print(l[:2000])
        sys.exit(1)
    pg.wait_for_timeout(a.wait)
    pg.screenshot(path=a.out, timeout=300000)
    b.close()
print(f'{a.out} {time.time() - t0:.0f}s')
for l in logs:
    if '[vite]' not in l: print(l[:600])
```

### A-3 向きを変えて何枚も撮る（`tools/views.py`）

```python
"""1 回だけ読み込み（影の焼き込みは 1 回）、見る向きを変えて何枚も撮る。
開発サーバーのページ（window.__scene が使える）で動く。
usage: python3 tools/views.py URL 出力の頭 名前=方位,仰角[,拡大[,横ずらし,縦ずらし]] ...
  例: python3 tools/views.py "http://127.0.0.1:5181/?hint=0&quality=low" shots/v front=-9,22.8 top=0,88 back=180,30 low=20,8
"""
import sys, time, json
from playwright.sync_api import sync_playwright

FLAGS = ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--enable-webgl', '--hide-scrollbars']
url, prefix = sys.argv[1], sys.argv[2]
views = []
for a in sys.argv[3:]:
    name, vals = a.split('=')
    v = [float(x) for x in vals.split(',')]
    st = {'azimuth': v[0], 'elevation': v[1], 'zoom': v[2] if len(v) > 2 else 1}
    if len(v) > 4:
        st.update({'panX': v[3], 'panY': v[4]})
    views.append((name, st))
with sync_playwright() as pw:
    b = pw.chromium.launch(args=FLAGS)
    # 動きを減らす設定：水の動きなどが止まり、毎回同じ画像になる（撮影も速い）
    pg = b.new_page(viewport={'width': 1200, 'height': 1000}, reduced_motion='reduce')
    logs = []
    pg.on('console', lambda m: logs.append(f'[{m.type}] {m.text}'))
    pg.on('pageerror', lambda e: logs.append(f'[pageerror] {e}'))
    t0 = time.time()
    pg.goto(url, wait_until='commit', timeout=600000)
    pg.wait_for_selector('#scene[data-ready="true"]', timeout=900000)
    print(f'ready {time.time() - t0:.0f}s', flush=True)
    for name, st in views:
        pg.evaluate(f'window.__scene.view.set({json.dumps(st)}, {{ animate: false }})')
        pg.wait_for_timeout(400)
        pg.evaluate('window.__scene.requestRender?.()')
        pg.wait_for_timeout(2500)
        pg.screenshot(path=f'{prefix}_{name}.png', timeout=300000)
        print(f'{prefix}_{name}.png', flush=True)
    b.close()
for l in logs:
    if '[vite]' not in l: print(l[:600])
```

### A-4 並べる・拡大して比べる（`tools/compare.py`）

```python
"""2 枚の画像を同じ幅で横に並べ、左上にラベルを付ける（参考画像と今回、直す前と直した後）。
usage: python3 tools/compare.py A.png B.png OUT.png --labels "参考画像" "今回" [--width 1000] [--crop x0,y0,x1,y1]
  --crop：両方の画像の同じ範囲（A の画素の座標。B は幅の比で合わせる）を切り抜いて縦に積む（拡大の比較）
"""
import argparse
from PIL import Image, ImageDraw, ImageFont

def font(size):
    for p in ['/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc', '/usr/share/fonts/truetype/noto/NotoSansCJK-Bold.ttc',
              '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf']:
        try:
            return ImageFont.truetype(p, size)
        except Exception:
            pass
    return ImageFont.load_default()

def label(im, x, y, text, f):
    d = ImageDraw.Draw(im, 'RGBA')
    bb = d.textbbox((0, 0), text, font=f)
    d.rounded_rectangle([x, y, x + bb[2] - bb[0] + 26, y + bb[3] - bb[1] + 20], 10, fill=(107, 79, 58, 225))
    d.text((x + 13, y + 10 - bb[1]), text, font=f, fill=(255, 248, 238))

ap = argparse.ArgumentParser()
ap.add_argument('a'); ap.add_argument('b'); ap.add_argument('out')
ap.add_argument('--labels', nargs=2, default=['参考画像', '今回'])
ap.add_argument('--width', type=int, default=1000)
ap.add_argument('--crop')
o = ap.parse_args()
A = Image.open(o.a).convert('RGB'); B = Image.open(o.b).convert('RGB'); w = o.width
if o.crop:
    x0, y0, x1, y1 = (int(v) for v in o.crop.split(','))
    k = B.width / A.width
    A = A.crop((x0, y0, x1, y1)); B = B.crop((int(x0 * k), int(y0 * k), int(x1 * k), int(y1 * k)))
    h = int(A.height * w / A.width)
    A = A.resize((w, h), Image.LANCZOS); B = B.resize((w, h), Image.LANCZOS)
    im = Image.new('RGB', (w, 2 * h + 12), (250, 232, 212)); im.paste(A, (0, 0)); im.paste(B, (0, h + 12))
    f = font(max(18, w // 38)); label(im, 14, 14, o.labels[0], f); label(im, 14, h + 26, o.labels[1], f)
else:
    A = A.resize((w, int(A.height * w / A.width)), Image.LANCZOS); B = B.resize((w, int(B.height * w / B.width)), Image.LANCZOS)
    im = Image.new('RGB', (2 * w + 12, max(A.height, B.height)), (250, 232, 212)); im.paste(A, (0, 0)); im.paste(B, (w + 12, 0))
    f = font(max(18, w // 33)); label(im, 18, 18, o.labels[0], f); label(im, w + 30, 18, o.labels[1], f)
im.save(o.out)
print(o.out, im.size)
```

### A-5 街の平面を確かめる（`tools/check_plan.py`）

```python
"""街の平面の確認：建物（長方形）が台座の内側に収まり、道と重ならず、互いに重ならず、
どの建物も入口になる面が道（歩道・広場・路地・裏路地）につながっているかを調べ、上から見た図を描く。
usage: python3 tools/check_plan.py plan.json plan.png
plan.json の例は手順書の「付録 A-5」。座標は上から見た [x, z]（台座の中心が 0、z は手前が正）
"""
import json, math, sys
import numpy as np
from shapely.geometry import Polygon, Point, LineString
from shapely.ops import unary_union
from PIL import Image, ImageDraw

spec = json.load(open(sys.argv[1]))
ped = spec.get('pedestal', {'half': 5.0, 'radius': 1.2, 'margin': 0.12})
HALF, RAD = ped['half'], ped['radius']

def rounded_square(half, r, n=16):
    pts = []
    for cx, cz, a0 in [(half - r, half - r, 0), (-(half - r), half - r, 90), (-(half - r), -(half - r), 180), (half - r, -(half - r), 270)]:
        for k in range(n + 1):
            a = math.radians(a0 + 90 * k / n)
            pts.append((cx + r * math.cos(a), cz + r * math.sin(a)))
    return Polygon(pts)

PED = rounded_square(HALF, RAD)
FR = {}
for name, f in spec.get('frames', {}).items():
    a = math.radians(f['dir'])
    u = np.array([math.cos(a), math.sin(a)])
    FR[name] = (np.array(f['point'], float), u, np.array([u[1], -u[0]]))   # d は u の左（奥）が正

def F(name, s, d):
    p, u, n = FR[name]
    q = p + s * u + d * n
    return (float(q[0]), float(q[1]))

def halfplane(name, d0, far=60):
    """枠 name で d >= d0 の側"""
    p, u, n = FR[name]
    a = p + d0 * n
    return Polygon([tuple(a - far * u), tuple(a + far * u), tuple(a + far * u + far * n), tuple(a - far * u + far * n)])

# 街区（歩道の高さ）：どの通りの縁石よりも奥。通りがなければ台座全体
block = PED
for st in spec.get('streets', []):
    block = block.intersection(halfplane(st['frame'], 0))
W_road = spec.get('roadWidth', 0)
road = PED.difference(block)
for st in spec.get('streets', []):
    road = road.intersection(halfplane(st['frame'], -W_road))
far = PED.difference(block).difference(road)            # 向かいの歩道
ways = []
for st in spec.get('streets', []):
    ways.append((f"sidewalk-{st['frame']}", block.difference(halfplane(st['frame'], st['sidewalk']))))
for w in spec.get('ways', []):
    if 'path' in w:
        line = LineString(w['path'])
    else:
        line = LineString([F(w['frame'], w['s'][0], w['d']), F(w['frame'], w['s'][1], w['d'])])
    ways.append((w['name'], line.buffer(w['width'] / 2, cap_style=2, join_style=2).intersection(block)))
for i, pz in enumerate(spec.get('plazas', [])):
    ways.append((f'plaza{i}', Polygon(pz).intersection(block)))
public = unary_union([g for _, g in ways] + [far])

blds = []
for b in spec['buildings']:
    pts = b.get('pts') or [F(b['rect'][0], b['rect'][1], b['rect'][3]), F(b['rect'][0], b['rect'][2], b['rect'][3]),
                           F(b['rect'][0], b['rect'][2], b['rect'][4]), F(b['rect'][0], b['rect'][1], b['rect'][4])]
    blds.append((b['id'], Polygon(pts), b.get('h', 3)))

problems = []
inner = PED.buffer(-ped.get('margin', 0.12))
for i, (bid, poly, h) in enumerate(blds):
    if not inner.contains(poly):
        problems.append(f'{bid}: 台座の縁に近すぎる・はみ出す（{poly.difference(inner).area:.3f}）')
    if not block.buffer(1e-6).contains(poly):
        problems.append(f'{bid}: 車道にはみ出す')
    for wn, wg in ways:
        a = poly.intersection(wg).area
        if a > 1e-4:
            problems.append(f'{bid}: 道 {wn} に重なる（{a:.3f}）')
    for bid2, poly2, _ in blds[i + 1:]:
        a = poly.intersection(poly2).area
        if a > 1e-5:
            problems.append(f'{bid} と {bid2} が重なる（{a:.3f}）')
# 道につながる空き地：0.2 縮めて（幅 0.4 未満のすき間は通れない）道に触れる部分
open_space = block.difference(unary_union([p for _, p, _ in blds]))
shrunk = open_space.buffer(-0.2)
parts = list(shrunk.geoms) if hasattr(shrunk, 'geoms') else [shrunk]
reach = unary_union([unary_union([g for g in parts if g.intersects(public.buffer(-0.05))]).buffer(0.2), public])
access = {}
for bid, poly, h in blds:
    pts = list(poly.exterior.coords)[:-1]
    cx, cz = poly.centroid.x, poly.centroid.y
    faces = []
    for k in range(len(pts)):
        a = np.array(pts[k]); c = np.array(pts[(k + 1) % len(pts)])
        t = (c - a) / np.linalg.norm(c - a); n = np.array([t[1], -t[0]])
        if np.dot(n, (a + c) / 2 - np.array([cx, cz])) < 0:
            n = -n
        # 面の何か所かで、外へ 0.18 の点が道につながるか（面の一部でも道に面していれば入れる）
        faces.append(any(reach.contains(Point(a + (c - a) * q + n * 0.18)) for q in (0.15, 0.3, 0.5, 0.7, 0.85)))
    access[bid] = faces
    if not any(faces):
        problems.append(f'{bid}: どの面も道に面していない（入れない）')

S, O = 80, HALF + 0.4
Wpx = int(2 * O * S)
im = Image.new('RGB', (Wpx, Wpx), (250, 246, 240)); d = ImageDraw.Draw(im, 'RGBA')
T = lambda p: ((p[0] + O) * S, (p[1] + O) * S)
def draw(g, fill, outline=None):
    for gg in (list(g.geoms) if hasattr(g, 'geoms') else [g]):
        if not gg.is_empty and gg.geom_type == 'Polygon':
            d.polygon([T(p) for p in gg.exterior.coords], fill=fill, outline=outline)
draw(PED, (60, 60, 66)); draw(road, (45, 45, 52)); draw(block, (200, 182, 162)); draw(far, (200, 182, 162))
for wn, wg in ways:
    draw(wg, (236, 214, 150, 200))
for bid, poly, h in blds:
    ok = any(access[bid])
    draw(poly, (90, 100, 190, 230) if ok else (220, 60, 60, 230), outline=(10, 10, 40))
    pts = list(poly.exterior.coords)[:-1]
    for k, f in enumerate(access[bid]):
        if f:
            d.line([T(pts[k]), T(pts[(k + 1) % len(pts)])], fill=(255, 220, 0), width=3)
    d.text(T((poly.centroid.x - 0.3, poly.centroid.y - 0.1)), f'{bid}\n{h:.1f}', fill=(255, 255, 255))
for k in range(-int(HALF), int(HALF) + 1):
    d.line([T((k, -O)), T((k, O))], fill=(0, 0, 0, 30)); d.line([T((-O, k)), T((O, k))], fill=(0, 0, 0, 30))
im.save(sys.argv[2])
print('\n'.join(problems) if problems else 'OK（重なりなし・台座の内側・どの建物も道に面している）')
```

`plan.json` の例（電気街。枠 L・R は 2 本の通りの縁石の線、A は路地の中心線。`rect` は `[枠, s1, s2, d1, d2]`）：

```json
{
  "pedestal": {"half": 5.0, "radius": 1.2, "margin": 0.12},
  "frames": {
    "L": {"point": [0, 2.89], "dir": 31.46},
    "R": {"point": [0, 3.8], "dir": -25.64},
    "A": {"point": [0.22, 1.3], "dir": -88.28}
  },
  "streets": [{"frame": "L", "sidewalk": 0.95}, {"frame": "R", "sidewalk": 0.7}],
  "roadWidth": 2.3,
  "ways": [
    {"name": "alley", "frame": "A", "s": [-1.0, 5.2], "d": 0, "width": 0.9},
    {"name": "laneL", "frame": "L", "s": [-9, -5.25], "d": 2.66, "width": 0.55},
    {"name": "laneR", "frame": "R", "s": [2.4, 9], "d": 4.97, "width": 0.55}
  ],
  "buildings": [
    {"id": "LB1", "rect": ["L", -6.3, -4.45, 0.95, 2.35], "h": 3.3},
    {"id": "LB1b", "rect": ["L", -4.45, -3.6, 0.95, 1.95], "h": 3.15},
    {"id": "LB2", "rect": ["R", 0.04, 1.02, 5.15, 6.8], "h": 4.62},
    {"id": "LB4", "rect": ["A", 2.2, 3.2, 0.45, 1.4], "h": 3.45},
    {"id": "LB3", "rect": ["A", 3.25, 4.4, 0.45, 1.75], "h": 4.35},
    {"id": "LBk3", "rect": ["A", 4.45, 6.1, 0.46, 1.9], "h": 3.4},
    {"id": "LB1u", "rect": ["L", -7.25, -6.05, 2.94, 4.6], "h": 3.6},
    {"id": "LBk1", "rect": ["L", -6.0, -5.3, 2.94, 4.5], "h": 3.2},
    {"id": "AE", "rect": ["A", 5.2, 6.12, -0.44, 0.44], "h": 3.4},
    {"id": "RB1", "rect": ["R", 2.74, 4.13, 0.7, 2.27], "h": 4.85},
    {"id": "RB2", "rect": ["R", 4.13, 4.85, 0.7, 2.27], "h": 4.6},
    {"id": "RB3", "rect": ["R", 4.85, 5.6, 0.7, 2.27], "h": 3.9},
    {"id": "RB1blue", "rect": ["A", 1.25, 2.9, -1.8, -0.45], "h": 5.3},
    {"id": "RBk2", "rect": ["A", 4.2, 6.1, -1.4, -0.46], "h": 4.6},
    {"id": "RBk1", "rect": ["R", 4.35, 5.6, 2.3, 4.67], "h": 4.2},
    {"id": "RBk4", "rect": ["R", 5.12, 6.05, 5.27, 6.5], "h": 3.7},
    {"id": "RBk5", "rect": ["R", 6.1, 6.95, 5.27, 6.2], "h": 3.3},
    {"id": "RBk7", "rect": ["R", 7.0, 7.5, 5.27, 5.85], "h": 3.5}
  ]
}
```

### A-6 参考画像の台座の外形を拾う（`tools/pick_outline.py`）

```python
"""参考画像から、台座の土台（木地の帯）の上端と下端を列ごとに拾う（カメラ合わせの観測点）。
色のしきい値と探す範囲は画像に合わせて変える。拾った点は確認用の画像に赤で描く。
usage: python3 tools/pick_outline.py reference.png obs.json [--ymin 950] [--ymax 1200] [--step 4] [--minrun 8]
"""
import argparse, json
import numpy as np
from PIL import Image, ImageDraw

ap = argparse.ArgumentParser()
ap.add_argument('image'); ap.add_argument('out')
ap.add_argument('--ymin', type=int, default=None); ap.add_argument('--ymax', type=int, default=None)
ap.add_argument('--step', type=int, default=4); ap.add_argument('--minrun', type=int, default=8)
o = ap.parse_args()
img = Image.open(o.image).convert('RGB')
im = np.asarray(img).astype(int)
H, W, _ = im.shape
ymin = o.ymin if o.ymin is not None else int(H * 0.75)
ymax = o.ymax if o.ymax is not None else H
R, G, B = im[..., 0], im[..., 1], im[..., 2]
# 木地の土台（#a58c6a 前後、明るさは光で変わる）：赤 > 緑 > 青 で、赤と青の差が大きい
plate = (R > 95) & (R < 230) & (R - G > 18) & (G - B > 22)
pts = []
for x in range(o.step, W - o.step, o.step):
    col = plate[ymin:ymax, x]
    best, i = (0, 0), 0
    while i < len(col):
        if col[i]:
            j = i
            while j < len(col) and col[j]:
                j += 1
            if j - i > best[1] - best[0]:
                best = (i, j)
            i = j
        else:
            i += 1
    # 探す範囲の端で切れた帯は使わない（範囲を広げて拾い直す）
    if best[1] - best[0] >= o.minrun and best[0] > 0 and best[1] < len(col):
        pts.append([x, ymin + best[0] - 0.5, ymin + best[1] - 0.5])
# 帯の高さがふつうと違う列（角で帯を横から見た所や、別の物を拾った所）は使わない
if pts:
    hs = np.array([p[2] - p[1] for p in pts])
    med = float(np.median(hs))
    pts = [p for p, hh in zip(pts, hs) if 0.6 * med <= hh <= 1.6 * med]
json.dump({'size': [W, H], 'plate': pts}, open(o.out, 'w'))
d = ImageDraw.Draw(img)
for x, yt, yb in pts:
    d.point((x, yt), fill=(255, 0, 0)); d.point((x, yb), fill=(255, 0, 0))
img.save(o.out.replace('.json', '_check.png'))
print(len(pts), 'columns', pts[:2], pts[-2:])
```

### A-7 カメラを合わせる（`tools/fit_camera.py`）

```python
"""参考画像の台座の外形に、シリーズのカメラを合わせる。
仰角 22.8°・距離 48.6（台座の幅の 4.86 倍）・注視点の高さ 1.905 はシリーズの値に固定し、
方位・焦点距離（画素）・画像の中心・傾き・土台の厚みを最小二乗で求める。
観測点は pick_outline.py の出力（土台の帯の上端・下端）。任意で "rim"（中身の塊の上の縁の点 [x, y]）も使える。
usage: python3 tools/fit_camera.py obs.json reference.png fit.json
出力の az・f・cx・cy を main.ts の ?refcam（REF）に、az を config.camera.azimuth の目安に使う
"""
import json, sys
import numpy as np
from scipy.optimize import least_squares
from PIL import Image, ImageDraw

obs = json.load(open(sys.argv[1]))
W, H = obs['size']
TY, D, EL = 1.905, 48.6, 22.8           # シリーズの注視点の高さ・距離・仰角
HALF, R = 5.0, 1.2                      # 台座（中身の塊）の半分の幅と角の半径
PH, PR = HALF - 0.12, R - 0.12          # 土台は一辺の 1.2% 内側
plate = np.array(obs['plate'], float)
rim = np.array(obs.get('rim', []), float).reshape(-1, 2)

def basis(az, el):
    a, e = np.radians(az), np.radians(el)
    cam = np.array([D * np.cos(e) * np.sin(a), TY + D * np.sin(e), D * np.cos(e) * np.cos(a)])
    fwd = np.array([0.0, TY, 0.0]) - cam; fwd /= np.linalg.norm(fwd)
    right = np.cross(fwd, [0, 1, 0]); right /= np.linalg.norm(right)
    return cam, fwd, right, np.cross(right, fwd)

def project(P, az, el, f, cx, cy, roll):
    cam, fwd, right, up = basis(az, el)
    d = P - cam
    u, v = f * (d @ right) / (d @ fwd), f * (d @ up) / (d @ fwd)
    c, s = np.cos(np.radians(roll)), np.sin(np.radians(roll))
    return np.stack([cx + c * u - s * v, cy - (s * u + c * v)], -1)

def outline(half, r, y, step=0.02):
    """角丸の正方形の外周（直線の辺と角の弧）を、間隔 step で並べた点。奥の辺は除く"""
    c, corners = half - r, []
    for sx, sz, a0 in [(1, 1, 0), (-1, 1, 90), (-1, -1, 180), (1, -1, 270)]:
        for k in range(24):
            a = np.radians(a0 + 90 * k / 23)
            corners.append((sx * c + r * np.cos(a), sz * c + r * np.sin(a)))
    ring = np.array(corners + corners[:1])
    pts = []
    for p0, p1 in zip(ring[:-1], ring[1:]):
        n = max(1, int(np.ceil(np.hypot(*(p1 - p0)) / step)))
        for k in range(n):
            pts.append(p0 + (p1 - p0) * k / n)
    pts = np.array(pts)
    pts = pts[pts[:, 1] > -c]            # 手前側だけ（奥の辺と奥の角は見えない）
    return np.stack([pts[:, 0], np.full(len(pts), y), pts[:, 1]], 1)

def dist(obs_xy, curve):
    d = np.hypot(curve[None, :, 0] - obs_xy[:, None, 0], curve[None, :, 1] - obs_xy[:, None, 1])
    i = d.argmin(axis=1)
    return np.sign(obs_xy[:, 1] - curve[i, 1]) * d.min(axis=1)

def residuals(q):
    az, f, cx, cy, t, h = q
    prm = (az, EL, f, cx, cy, 0.0)        # 傾き（roll）は 0 に固定（シリーズのカメラは水平）
    r = [dist(plate[:, [0, 2]], project(outline(PH, PR, 0.0), *prm)),     # 土台の下端（床）
         dist(plate[:, [0, 1]], project(outline(PH, PR, t), *prm))]       # 土台の上端
    if len(rim):
        r.append(0.7 * dist(rim, project(outline(HALF, R, h), *prm)))    # 中身の塊の上の縁
    return np.concatenate(r)

best = None
for az0 in (-20, -10, -3, 4, 12):
    q0 = np.array([az0, W * 4.15, W / 2, H * 0.55, 0.255, 1.2])
    r = least_squares(residuals, q0, x_scale=[1, 200, 10, 10, 0.05, 0.1])
    rms = np.sqrt(np.mean(r.fun ** 2))
    print(f'  始めの方位 {az0:+}° → rms {rms:.2f}px, 方位 {r.x[0]:.2f}°', flush=True)
    if best is None or rms < best[0]:
        best = (rms, r.x)
rms, q = best
az, f, cx, cy, t, h = q
roll = 0.0
fov = np.degrees(2 * np.arctan(H / 2 / f))
print(f'rms {rms:.2f}px  az {az:.3f}  f {f:.1f}（縦の画角 {fov:.2f}°）  cx {cx:.2f}  cy {cy:.2f}  土台の厚み {t:.3f}  縁の高さ {h:.3f}')
json.dump({'az': az, 'el': EL, 'f': f, 'cx': cx, 'cy': cy, 'roll': roll, 't': t, 'h': h, 'size': [W, H], 'D': D, 'ty': TY}, open(sys.argv[3], 'w'), indent=1)
img = Image.open(sys.argv[2]).convert('RGB'); dr = ImageDraw.Draw(img)
prm = (az, EL, f, cx, cy, roll)
for (half, r_, y), col in (((PH, PR, 0.0), (255, 0, 255)), ((PH, PR, t), (0, 255, 0)), ((HALF, R, h), (0, 200, 255))):
    p = project(outline(half, r_, y), *prm)
    dr.line([tuple(v) for v in p], fill=col, width=2)
img.save(sys.argv[3].replace('.json', '_check.png'))
```

### A-8 画像の点と 3D の点を行き来する（`tools/backproject.py`）

```python
"""参考画像の点 ⇄ 3D の点（fit_camera.py で求めたカメラで）。
  画像の点 → 高さ y の水平な面の上の点（逆投影）：python3 tools/backproject.py fit.json to3d <y> <px> <py> [<px> <py> ...]
  3D の点 → 画像の点（投影）：                    python3 tools/backproject.py fit.json to2d <x> <y> <z> [...]
座標は上から見た x（右が正）、z（手前が正）、y は床が 0（土台の上面が 0.255）。
建物の足もと・岩の中心・道の角など、参考画像で拾った点を平面の座標に直すのに使う
"""
import json, sys
import numpy as np

C = json.load(open(sys.argv[1]))
a, e = np.radians(C['az']), np.radians(C['el'])
D, TY, F, CX, CY = C['D'], C['ty'], C['f'], C['cx'], C['cy']
CAM = np.array([D * np.cos(e) * np.sin(a), TY + D * np.sin(e), D * np.cos(e) * np.cos(a)])
FWD = np.array([0.0, TY, 0.0]) - CAM; FWD /= np.linalg.norm(FWD)
RIGHT = np.cross(FWD, [0, 1, 0]); RIGHT /= np.linalg.norm(RIGHT)
UP = np.cross(RIGHT, FWD)

def to2d(p):
    d = np.asarray(p, float) - CAM
    return CX + F * (d @ RIGHT) / (d @ FWD), CY - F * (d @ UP) / (d @ FWD)

def to3d(px, py, y):
    ray = FWD + (px - CX) / F * RIGHT - (py - CY) / F * UP
    t = (y - CAM[1]) / ray[1]
    return CAM + t * ray

mode, vals = sys.argv[2], [float(v) for v in sys.argv[3:]]
if mode == 'to3d':
    y = vals[0]
    for px, py in zip(vals[1::2], vals[2::2]):
        p = to3d(px, py, y)
        print(f'({px:.0f}, {py:.0f}) → x {p[0]:.3f}, y {p[1]:.3f}, z {p[2]:.3f}')
else:
    for x, y, z in zip(vals[0::3], vals[1::3], vals[2::3]):
        u, v = to2d([x, y, z])
        print(f'({x}, {y}, {z}) → 画像の ({u:.1f}, {v:.1f})')
```

### A-9 そのまま開ける 1 枚の HTML にまとめる（`tools/build_single_html.py`）

```python
"""箱庭のプロジェクトを、そのまま開ける 1 枚の HTML ファイルにまとめる（コード・書体・画面の CSS をすべて入れる）。
three.js は既定では CDN（jsDelivr）から読む。--bundle-three を付けると three.js もファイルに入れ、ネットワークなしで開ける。
usage: python3 tools/build_single_html.py <プロジェクトのフォルダ> <ページのタイトル> <出力.html> [--three 0.186.1] [--bundle-three]
確認は、出力のフォルダで python3 -m http.server を立てて開く（file:// で開くとモジュールの読み込みが止められることがある）
"""
import argparse, os, re, subprocess, sys, tempfile, shutil

ap = argparse.ArgumentParser()
ap.add_argument('project'); ap.add_argument('title'); ap.add_argument('out')
ap.add_argument('--three', default='0.186.1')
ap.add_argument('--bundle-three', action='store_true')
o = ap.parse_args()
P = os.path.abspath(o.project)
build_dir = tempfile.mkdtemp(prefix='single-html-')
cfg = os.path.join(P, '.vite-single.config.mjs')
external = '' if o.bundle_three else "rolldownOptions: { external: ['three'] },"
open(cfg, 'w').write(f"""export default {{
  root: '{P}', logLevel: 'warn', publicDir: false,
  build: {{ outDir: '{build_dir}', emptyOutDir: true, minify: {'true' if o.bundle_three else 'false'}, sourcemap: false,
    lib: {{ entry: '{P}/src/main.ts', formats: ['es'], fileName: () => 'app.js' }},
    {external} }},
}};
""")
r = subprocess.run(['npx', 'vite', 'build', '--config', cfg], cwd=P, capture_output=True, text=True)
os.remove(cfg)
if r.returncode != 0:
    print(r.stdout[-3000:], r.stderr[-3000:]); sys.exit(1)
app = open(os.path.join(build_dir, 'app.js'), encoding='utf-8').read()
shutil.rmtree(build_dir, ignore_errors=True)
prelude = ''
if not o.bundle_three:
    # three の読み込みを、ページの先頭で CDN から読む THREE にそろえる
    star = re.findall(r'^import \* as (\w+) from ["\']three["\'];\n', app, flags=re.M)
    app = re.sub(r'^import \* as \w+ from ["\']three["\'];\n', '', app, flags=re.M)
    def destructure(m):
        parts = []
        for n in [n.strip() for n in m.group(1).split(',') if n.strip()]:
            a, _, b = n.partition(' as ')
            parts.append(f'{a.strip()}: {b.strip()}' if b else a.strip())
        return 'const { ' + ', '.join(parts) + ' } = THREE;\n'
    app = re.sub(r'^import \{([^}]*)\} from ["\']three["\'];\n', destructure, app, flags=re.M)
    prelude = (f'import * as THREE from "https://cdn.jsdelivr.net/npm/three@{o.three}/build/three.module.js";\n'
               + ''.join(f'const {a} = THREE;\n' for a in sorted(set(star)) if a != 'THREE'))
assert "from 'three'" not in app and 'from "three"' not in app, 'three の import が残っています'
assert '</script' not in app.lower(), 'コードの中に </script があります'
css = open(os.path.join(P, 'src/style.css'), encoding='utf-8').read()
index_html = open(os.path.join(P, 'index.html'), encoding='utf-8').read()
canvas = re.search(r'<canvas id="scene"[^>]*></canvas>', index_html).group(0)
message = re.search(r'<p id="scene-message"[^>]*></p>', index_html).group(0)
hint = re.search(r'<p id="scene-hint"[^>]*></p>', index_html).group(0)
page = f"""<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#fae8d4">
<title>{o.title}</title>
<style>
{css}
</style>
</head>
<body>
{canvas}
{message}
{hint}
<script type="module" id="scene-app">
{prelude}{app}</script>
<script>
  // three.js を読み込めなかったときの案内
  document.getElementById("scene-app").addEventListener("error", function () {{
    var el = document.getElementById("scene-message");
    if (!el) return;
    el.textContent = "3D表示に必要な Three.js を読み込めませんでした。ネットワーク接続を確認して、ページを再読み込みしてください。";
    el.hidden = false;
  }});
</script>
</body>
</html>
"""
os.makedirs(os.path.dirname(os.path.abspath(o.out)), exist_ok=True)
open(o.out, 'w', encoding='utf-8').write(page)
print(f'{o.out}: {len(page.encode("utf-8")):,} bytes（three.js は {"ファイルの中" if o.bundle_three else "CDN"}）')
```

### A-10 書体を絞って埋め込む（`tools/subset_fonts.py` と読み込み）

```python
"""看板などに使う書体を、使う文字だけに絞って WOFF2 にし、base64 で埋め込む TypeScript のモジュールを書き出す。
書体は SIL Open Font License（OFL）のものを使い、ライセンスの情報（name 表）は残す。
usage: python3 tools/subset_fonts.py <出力の fontData.ts> "<書体の名前>=<ttf のパス>=<使う文字を書いたテキストファイル>" ...
  例: python3 tools/subset_fonts.py src/town/fontData.ts "Dela Gothic One=fonts/DelaGothicOne-Regular.ttf=chars_gothic.txt"
読み込みは fonts.ts の loadSignFonts()（new FontFace(名前, ArrayBuffer) → document.fonts.add）で行う
必要：pip install fonttools brotli
"""
import base64, os, subprocess, sys, tempfile
from fontTools.ttLib import TTFont

out_ts = sys.argv[1]
items = []
for arg in sys.argv[2:]:
    family, ttf, textfile = arg.split('=')
    text = open(textfile, encoding='utf-8').read()
    # 数字・英字・よく使う記号も入れておく（看板の予備）
    text += '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz&-・ '
    cmap = TTFont(ttf).getBestCmap()
    missing = sorted({c for c in text if ord(c) not in cmap and not c.isspace()})
    if missing:
        print(f'注意: {family} にない文字 {"".join(missing)}（端末の書体で描かれる）')
    tmp_txt = tempfile.mktemp(suffix='.txt'); open(tmp_txt, 'w', encoding='utf-8').write(text)
    woff2 = tempfile.mktemp(suffix='.woff2')
    subprocess.run(['pyftsubset', ttf, f'--text-file={tmp_txt}', '--flavor=woff2', f'--output-file={woff2}',
                    '--name-IDs=*', '--name-legacy', '--name-languages=*', '--no-hinting', '--layout-features=*'], check=True)
    data = open(woff2, 'rb').read()
    copyright_ = TTFont(woff2)['name'].getDebugName(0) or ''
    items.append((family, base64.b64encode(data).decode(), copyright_, len(data)))
    print(f'{family}: {len(data):,} bytes')
lines = ['/**', ' * 埋め込みの書体（使う文字だけに絞った WOFF2 を base64 で）。どれも SIL Open Font License 1.1。']
for family, _, c, _ in items:
    lines.append(f' *  - {family}: {c}')
lines += [' */', 'export const SIGN_FONTS: { family: string; data: string }[] = [']
for family, b64, _, _ in items:
    lines.append(f"  {{ family: '{family}', data: '{b64}' }},")
lines.append('];')
open(out_ts, 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
print(out_ts, f'合計 {sum(i[3] for i in items):,} bytes')
```

書体の取り方（例：Dela Gothic One）とライセンス：

```bash
mkdir -p fonts && cd fonts
curl -sSLO https://raw.githubusercontent.com/google/fonts/main/ofl/delagothicone/DelaGothicOne-Regular.ttf
curl -sSL -o DelaGothicOne-OFL.txt https://raw.githubusercontent.com/google/fonts/main/ofl/delagothicone/OFL.txt
# OFL.txt の 1 行目に Reserved Font Name がないことを確かめる（あると、絞った書体を同じ名前で配れない）
```

電気街で使った書体：Dela Gothic One（`delagothicone`）、DotGothic16（`dotgothic16`）、Zen Maru Gothic Black（`zenmarugothic/ZenMaruGothic-Black.ttf`）、RocknRoll One（`rocknrollone`）、Bungee（`bungee`）。

読み込み（`src/town/fonts.ts`。`main.ts` で `loadSignFonts().then(() => boot(canvas), () => boot(canvas))` のように、読み込んでから街を作る）：

```ts
/*! 看板の書体: Dela Gothic One (c) 2020 The Dela Gothic Project Authors / DotGothic16 (c) 2020 The DotGothic16 Project Authors /
 * Zen Maru Gothic (c) 2021 The Zen Maru Gothic Project Authors / RocknRoll One (c) 2020 The RocknRoll Project Authors /
 * Bungee (c) 2023 The Bungee Project Authors — SIL Open Font License 1.1 (https://openfontlicense.org)。使う文字だけに絞って埋め込み */
import { SIGN_FONTS } from './fontData';

/**
 * 看板の書体を読み込む（埋め込みのデータから。ネットワークは使わない）。
 * 読み込めない・時間がかかるときは待たずに進み、看板は端末の書体で描く
 */
export async function loadSignFonts(timeoutMs = 4000): Promise<void> {
  if (typeof FontFace === 'undefined' || typeof document === 'undefined' || !document.fonts) return;
  const loads = SIGN_FONTS.map(async (f) => {
    const bin = Uint8Array.from(atob(f.data), (c) => c.charCodeAt(0));
    const face = new FontFace(f.family, bin.buffer, { weight: '400', style: 'normal', display: 'block' });
    await face.load();
    document.fonts.add(face);
  });
  let timer = 0;
  await Promise.race([
    Promise.allSettled(loads),
    new Promise<void>((resolve) => {
      timer = window.setTimeout(resolve, timeoutMs);
    }),
  ]);
  window.clearTimeout(timer);
}
```

### A-11 参考画像のカメラ（`main.ts` の `?refcam`）

`updateCamera()` の最初に入れます。`REF` は `fit_camera.py` の結果（az・f・cx・cy と参考画像の大きさ）。比較の撮影は参考画像と同じ大きさで行います。

```ts
// ?refcam：参考画像に合わせたカメラで撮る（比較用）。値は tools/fit_camera.py の結果
const refcam = params.has('refcam');
const REF = { azimuth: -8.807, elevation: 22.8, f: 5196.66, cx: 610.33, cy: 686.53, width: 1254, height: 1254 };
const updateCamera = () => {
  if (refcam) {
    camera.position.copy(directionFromAngles(REF.azimuth, REF.elevation)).multiplyScalar(distance).add(lookAt);
    camera.lookAt(lookAt);
    camera.updateMatrixWorld();
    const k = viewH / REF.height;
    camera.aspect = viewW / viewH;
    camera.fov = THREE.MathUtils.radToDeg(2 * Math.atan(REF.height / 2 / REF.f));
    camera.setViewOffset(viewW, viewH, (REF.width / 2 - REF.cx) * k, (REF.height / 2 - REF.cy) * k, viewW, viewH);
    camera.updateProjectionMatrix();
    return;
  }
  // …ここから既定の構図（シリーズ共通のまま）
};
```
