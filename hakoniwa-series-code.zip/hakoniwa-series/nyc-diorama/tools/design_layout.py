"""ニューヨークの箱庭の配置（layout.json）を作る。

台座はシリーズ共通の角丸の正方形（一辺 10、角の半径 1.2）。カメラは手前（+z）の正面から見下ろす。
  - 島（ロウアー・マンハッタン）は奥に置き、手前はイースト川、左は湾、奥はハドソン川。右の縁で島を切る（島は北へ続く）
  - 道路は 1 本の網：島を回る海沿いの通り（手前は FDR ドライブ、奥はウェスト・サイド・ハイウェイ）、
    東西の大通り（A1）、南北の通り（S1、S2）。どの道の端も交差点か、台座の縁の切り口で終わる
  - ブルックリン橋は S2 の上の坂道から海沿いの通りをまたいで岸の橋台へ上がり、川を斜めに渡って手前右の縁で切れる
  - 区画は「島から道路を除いた所」。角を丸め、建物は区画の通り側から歩道の幅だけ下げて置く

座標：x は右、z は手前（カメラの側）、高さは島の地面からの値（道路の面が 0）。
使い方：python3 tools/design_layout.py [plan.png]   （src/layout.json を書き、走行テストの結果を表示する）
"""
import json
import math
import sys
from pathlib import Path

from shapely.geometry import LineString, MultiLineString, MultiPolygon, Point, Polygon, box
from shapely.ops import unary_union

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'src' / 'layout.json'

# ---------------------------------------------------------------- 台座と島
HALF, CORNER = 5.0, 1.2


def rounded_square(h, r, n=24):
    pts = []
    for cx, cz, a0 in [(h - r, -h + r, -90), (h - r, h - r, 0), (-h + r, h - r, 90), (-h + r, -h + r, 180)]:
        for i in range(n + 1):
            a = math.radians(a0 + 90 * i / n)
            pts.append((cx + r * math.cos(a), cz + r * math.sin(a)))
    return Polygon(pts)


PED = rounded_square(HALF, CORNER)
# 島は台座の外形よりほんのわずか外まで（切り口の面が水の塊の側面より手前に来るように）
PED_CUT = rounded_square(HALF + 0.004, CORNER + 0.004)

Z_FRONT = 1.35   # 手前の岸（護岸）
Z_BACK = -4.25   # 奥の岸
TIP_X = -4.15    # 左の先端（バッテリー）
TIP_Z = -1.4
TIP_CX = -1.7    # 先端の丸みの始まり
X_END = 4.7      # 右の端の岸（島はここで終わり、まわりは水。シリーズの島と同じく台座の縁に触れない）
R_END = 0.9      # 右の端の角の丸み


def island_outline():
    a = TIP_CX - TIP_X
    bf = Z_FRONT - TIP_Z
    bb = TIP_Z - Z_BACK
    pts = []
    # 右手前の角（右の岸 → 手前の岸）
    cx, czf, czb = X_END - R_END, Z_FRONT - R_END, Z_BACK + R_END
    for i in range(0, 13):
        t = math.radians(90 * i / 12)
        pts.append((cx + R_END * math.cos(t), czf + R_END * math.sin(t)))
    # 手前の岸 → 左の先端 → 奥の岸
    for i in range(0, 41):
        t = math.radians(90 + 90 * i / 40)
        pts.append((TIP_CX + a * math.cos(t), TIP_Z + bf * math.sin(t)))
    for i in range(1, 41):
        t = math.radians(180 + 90 * i / 40)
        pts.append((TIP_CX + a * math.cos(t), TIP_Z + bb * math.sin(t)))
    # 右奥の角（奥の岸 → 右の岸）
    for i in range(0, 13):
        t = math.radians(-90 + 90 * i / 12)
        pts.append((cx + R_END * math.cos(t), czb + R_END * math.sin(t)))
    return Polygon(pts)


ISLAND_RAW = island_outline()
ISLAND = ISLAND_RAW.intersection(PED_CUT)

# ---------------------------------------------------------------- 道路
PROM = 0.22        # 岸の遊歩道の幅
W_DRIVE = 0.42     # 海沿いの通り・大通り
W_STREET = 0.4     # 南北の通り
W_RAMP = 0.64      # 橋へ上がる坂道（橋の路面と同じ幅）
SIDEWALK = 0.13    # 区画の縁から建物までの歩道の幅

ring = ISLAND_RAW.buffer(-(PROM + W_DRIVE / 2), join_style='round', quad_segs=24).exterior
# 島を一周する閉じた輪（端がない）。手前の通り（FDR ドライブ）の中ほどから始める
coords = list(ring.coords)[:-1]
start = min(range(len(coords)), key=lambda i: math.hypot(coords[i][0] - 1.0, coords[i][1] - (Z_FRONT - PROM - W_DRIVE / 2)))
coords = coords[start:] + coords[:start]
# 手前の通りを右（+x）へ進む向きにそろえる（右側通行の車線の向きの基準）
if coords[1][0] < coords[0][0]:
    coords = [coords[0]] + coords[1:][::-1]
RING = LineString(coords + [coords[0]])
Z_FDR = Z_FRONT - PROM - W_DRIVE / 2          # 手前の海沿いの通りの中心
Z_WSH = Z_BACK + PROM + W_DRIVE / 2           # 奥の海沿いの通りの中心
Z_A1 = -1.55                                   # 東西の大通り
X_S1 = -0.55                                   # 南北の通り
X_S2 = 2.45                                    # 橋の通り


def x_on_ring(z, left=True):
    """海沿いの通りの中心線が高さ z を横切る x（左の先端の側）"""
    line = LineString([(-6, z), (6, z)])
    hit = RING.intersection(line)
    pts = [hit] if isinstance(hit, Point) else list(getattr(hit, 'geoms', []))
    xs = sorted(p.x for p in pts)
    return xs[0] if left else xs[-1]


A1 = LineString([(x_on_ring(Z_A1), Z_A1), (x_on_ring(Z_A1, left=False), Z_A1)])
S1 = LineString([(X_S1, Z_WSH), (X_S1, Z_FDR)])
S2_GRADE = LineString([(X_S2, Z_WSH), (X_S2, Z_A1)])
RAMP_Z0 = Z_A1 + W_DRIVE / 2                   # 坂道の始まり（大通りの手前の縁）
RAMP_Z1 = Z_FRONT + 0.32                       # 橋台の前の面（岸から少し水の上へ）
S2_RAMP = LineString([(X_S2, Z_A1), (X_S2, RAMP_Z1)])

roads = [
    {'name': 'waterfront', 'kind': 'drive', 'width': W_DRIVE, 'center': 'double', 'path': [list(map(lambda v: round(v, 4), p)) for p in RING.coords]},
    {'name': 'avenue', 'kind': 'avenue', 'width': W_DRIVE, 'center': 'double', 'path': [list(p) for p in A1.coords]},
    {'name': 'street-west', 'kind': 'street', 'width': W_STREET, 'center': 'dashed', 'path': [list(p) for p in S1.coords]},
    {'name': 'street-bridge', 'kind': 'street', 'width': W_STREET, 'center': 'dashed', 'path': [list(p) for p in S2_GRADE.coords]},
]


def road_poly(line, w):
    return line.buffer(w / 2, cap_style='flat', join_style='round', quad_segs=16)


ROAD_POLYS = [road_poly(RING, W_DRIVE), road_poly(A1, W_DRIVE), road_poly(S1, W_STREET), road_poly(S2_GRADE, W_STREET)]
RAMP_POLY = box(X_S2 - W_RAMP / 2, RAMP_Z0, X_S2 + W_RAMP / 2, Z_FRONT)
ROADS = unary_union(ROAD_POLYS + [RAMP_POLY])
# 交差点（道路どうしが重なる所）：中央線や白線を描かない
JUNCTIONS = unary_union([ROAD_POLYS[i].intersection(ROAD_POLYS[j]).buffer(0.03) for i in range(len(ROAD_POLYS)) for j in range(i + 1, len(ROAD_POLYS))])

# ---------------------------------------------------------------- 区画（島から道路を除いた所。角を丸める）
blocks_raw = ISLAND_RAW.difference(ROADS)
blocks = []
for g in getattr(blocks_raw, 'geoms', [blocks_raw]):
    r = g.buffer(0.07, join_style='round').buffer(-0.14, join_style='round').buffer(0.07, join_style='round')
    r = r.intersection(PED_CUT)
    for h in getattr(r, 'geoms', [r]):
        if h.area > 0.05:
            blocks.append(h.simplify(0.004))


def block_at(x, z):
    for b in blocks:
        if b.contains(Point(x, z)):
            return b
    return None


# ---------------------------------------------------------------- 公園
CITY_HALL = block_at(0.9, -0.3).buffer(-SIDEWALK, join_style='round')
tip_cut_front = box(-6, Z_A1 + W_DRIVE / 2, -2.55, Z_FDR)
tip_cut_back = box(-6, Z_WSH, -2.75, Z_A1 - W_DRIVE / 2)
BATTERY = unary_union([
    block_at(-3.0, -0.3).intersection(tip_cut_front),
    block_at(-3.2, -2.6).intersection(tip_cut_back),
]).buffer(-SIDEWALK, join_style='round')
parks = [
    {'name': 'city-hall-park', 'poly': CITY_HALL, 'pond': {'c': [0.85, -0.38], 'r': [0.42, 0.3]}},
    {'name': 'battery-park', 'poly': BATTERY, 'fort': {'c': [-3.55, -0.62], 'r': 0.22}},
]

# ---------------------------------------------------------------- 建物（いまの形のひな形を、新しい区画へ移す）
OLD = json.load(open(ROOT / 'tools' / 'building_templates.json'))  # 建物の形のひな形（部品の組み合わせ）
OLD_BY_NAME = {b['name']: b for b in OLD['buildings']}


def moved(name, new_c, rename=None, scale_h=1.0):
    b = OLD_BY_NAME[name]
    base = next(p for p in b['parts'] if p['type'] in ('box', 'antiprism', 'taper'))
    dx = new_c[0] - base['c'][0]
    dz = new_c[1] - base['c'][1]
    parts = []
    for p in b['parts']:
        q = dict(p)
        q['c'] = [round(p['c'][0] + dx, 4), round(p['c'][1] + dz, 4)]
        if scale_h != 1.0:
            q['y'] = [round(p['y'][0] * scale_h, 4), round(p['y'][1] * scale_h, 4)]
        parts.append(q)
    return {'name': rename or name, 'parts': parts}


def simple(name, c, size, h, style, roof=None, setback=None):
    parts = [{'type': 'box', 'c': list(c), 'size': list(size), 'y': [0, h], 'style': style}]
    if setback:
        s2, h2 = setback
        parts.append({'type': 'box', 'c': list(c), 'size': list(s2), 'y': [h, h2], 'style': style})
        h = h2
    if roof:
        parts.append({'type': 'box', 'c': [c[0] + 0.02, c[1] - 0.02], 'size': [size[0] * 0.5, size[1] * 0.5], 'y': [h, h + 0.12], 'style': 'roofbox'})
    return {'name': name, 'parts': parts}


TOWER_SCALE = 0.82
buildings = [
    # 奥の区画：左にワン・ワールド・トレード・センター、中ほどにエンパイア・ステート・ビル（正面から見て高い塔が左右に並ぶ）
    # 超高層の 2 本は高さだけ少し縮める（模型の「選択的圧縮」。シリーズの構図で台座を小さくしすぎないように）
    moved('one-wtc', (-1.99, -2.64), scale_h=TOWER_SCALE),
    moved('gray-tower-mid', (-1.17, -2.3)),
    moved('empire-state', (0.62, -2.7), scale_h=TOWER_SCALE),
    moved('glass-box', (1.74, -3.1)),
    simple('mid-gray-back', (1.74, -2.22), (0.52, 0.56), 2.25, 'gray', roof=True),
    moved('tan-copper', (3.13, -3.1)),
    simple('tan-back', (3.66, -3.2), (0.34, 0.4), 2.0, 'tan', roof=False),
    moved('tan-brick', (3.12, -2.22)),
    simple('east-slim', (3.62, -2.25), (0.36, 0.52), 1.6, 'brick', roof=True),
    # 手前の区画：右に緑の銅の屋根の塔（市庁舎の近くの古い塔）とれんが、左に灰色の塔と中くらいの塔
    moved('beaux-arts', (3.42, -0.72)),
    moved('gray-tower-west', (-2.2, -0.84)),
    moved('small-brick', (-1.08, -0.98)),
    simple('mid-tan-west', (-1.55, -0.8), (0.48, 0.5), 2.35, 'tan', roof=True, setback=((0.36, 0.38), 2.6)),
    # 港の古いれんがの低い建物（サウス・ストリート・シーポート）
    simple('seaport-row-1', (-1.94, 0.17), (0.82, 0.46), 0.56, 'tanbrick', roof=True),
    simple('seaport-row-2', (-1.22, 0.24), (0.6, 0.48), 0.48, 'brick'),
    simple('seaport-east-1', (3.42, 0.26), (0.92, 0.52), 0.62, 'brick', roof=True),
]
waterTanks = [
    {'c': [-1.94, 0.17], 'y': 0.68, 's': 0.8},
    {'c': [3.42, 0.26], 'y': 0.74, 's': 0.8},
    {'c': [3.12, -2.22], 'y': 1.87},
    {'c': [-1.08, -0.98], 'y': 1.2},
    {'c': [3.62, -2.25], 'y': 1.72, 's': 0.75},
    {'c': [3.66, -3.2], 'y': 2.0, 's': 0.8},
]

# ---------------------------------------------------------------- 橋（坂道 → 海沿いの通りをまたぐ → 岸の橋台 → 川を斜めに → 手前右の縁）
SPAN_DEG = 25.0
sd = (math.sin(math.radians(SPAN_DEG)), math.cos(math.radians(SPAN_DEG)))
anchor_front = (X_S2, RAMP_Z1)
span_len = 3.5                        # 橋台の前の面から、切り口まで（路面の右の角が台座の縁に届く所）
tower_s = 1.55                         # 橋台から主塔まで
tower_at = (anchor_front[0] + sd[0] * tower_s, anchor_front[1] + sd[1] * tower_s)
cut_end = (anchor_front[0] + sd[0] * span_len, anchor_front[1] + sd[1] * span_len)
# 路面の高さ（島の地面から。水面は -0.12）
H_FDR = 0.3      # 海沿いの通りの上（タクシーの屋根の上に 0.07 のすき間）
bridge = {
    # [x, z, 高さ]：坂道の始まり → 海沿いの通りの手前 → 岸 → 橋台の前 → 主塔 → 切り口
    'path': [
        [X_S2, round(RAMP_Z0, 4), 0.0],
        [X_S2, round(Z_FDR - W_DRIVE / 2 - 0.02, 4), 0.285],
        [X_S2, round(Z_FDR + W_DRIVE / 2 + 0.05, 4), H_FDR],
        [X_S2, round(RAMP_Z1, 4), 0.32],
        [round(anchor_front[0] + sd[0] * 0.5, 4), round(anchor_front[1] + sd[1] * 0.5, 4), 0.385],
        [round(tower_at[0], 4), round(tower_at[1], 4), 0.52],
        [round(cut_end[0], 4), round(cut_end[1], 4), 0.68],
    ],
    'width': W_RAMP,
    'tower': {'at': [round(tower_at[0], 4), round(tower_at[1], 4)], 'top': 2.3, 'along': 0.34, 'across': 1.32},
    # 坂道（擁壁で支える区間）と、海沿いの通りをまたぐ石のアーチ、岸の橋台（ケーブルを留める）
    'ramp': {'z': [round(RAMP_Z0, 4), round(Z_FDR - W_DRIVE / 2, 4)]},
    'arch': {'z': [round(Z_FDR - W_DRIVE / 2, 4), round(Z_FDR + W_DRIVE / 2, 4)]},
    'anchorage': {'c': [X_S2, round((Z_FDR + W_DRIVE / 2 + RAMP_Z1) / 2, 4)], 'size': [0.92, round(RAMP_Z1 - (Z_FDR + W_DRIVE / 2), 4)], 'top': 0.47},
    'spanDir': [round(sd[0], 5), round(sd[1], 5)],
}

# ---------------------------------------------------------------- 桟橋（ピア 17）とフェリー
pier = {'deck': [-1.0, 0.8, Z_FRONT - 0.02, 2.62], 'deckY': 0.0, 'shed': [-0.9, 0.7, 1.48, 2.5], 'shedY': [0, 0.36], 'roofY': 0.47}
ferry = {'c': [-2.35, 3.35], 'length': 1.95, 'width': 0.56, 'heading': -100}

# ---------------------------------------------------------------- 横断歩道（交差点の各方向）
crosswalks = []


def add_crosswalk(cx, cz, along, length, depth=0.15):
    """along：横断歩道が渡る道の向き（その道を横切る帯）。length は道の幅"""
    crosswalks.append({'c': [round(cx, 4), round(cz, 4)], 'dir': along, 'length': round(length, 3), 'depth': depth})


def cross_x(x_road, w_road, z, w_other, sides=(-1, 1)):
    # 南北の道（x_road）を、東西の道（z）の手前と奥で横切る
    for s in sides:
        add_crosswalk(x_road, z + s * (w_other / 2 + 0.1), 'z', w_road)


def cross_z(z_road, w_road, x, w_other, sides=(-1, 1)):
    for s in sides:
        add_crosswalk(x + s * (w_other / 2 + 0.1), z_road, 'x', w_road)


cross_x(X_S1, W_STREET, Z_A1, W_DRIVE)
cross_z(Z_A1, W_DRIVE, X_S1, W_STREET)
cross_z(Z_A1, W_DRIVE, X_S2, W_STREET, sides=(-1, 1))
cross_x(X_S2, W_STREET, Z_A1, W_DRIVE, sides=(-1,))
cross_z(Z_FDR, W_DRIVE, X_S1, W_STREET)
cross_x(X_S1, W_STREET, Z_FDR, W_DRIVE, sides=(-1,))
cross_z(Z_WSH, W_DRIVE, X_S1, W_STREET)
cross_x(X_S1, W_STREET, Z_WSH, W_DRIVE, sides=(1,))
cross_z(Z_WSH, W_DRIVE, X_S2, W_STREET)
cross_x(X_S2, W_STREET, Z_WSH, W_DRIVE, sides=(1,))
# 大通りの両端（海沿いの通りとの T 字路）：大通りと、海沿いの通りを渡る
for xa, sgn in [(A1.coords[0][0], 1), (A1.coords[-1][0], -1)]:
    add_crosswalk(xa + sgn * (W_DRIVE / 2 + 0.12), Z_A1, 'x', W_DRIVE)
    add_crosswalk(xa, Z_A1 + W_DRIVE / 2 + 0.12, 'z', W_DRIVE)
    add_crosswalk(xa, Z_A1 - W_DRIVE / 2 - 0.12, 'z', W_DRIVE)
# 桟橋の前：海沿いの通りを渡る
add_crosswalk(-0.1, Z_FDR, 'x', W_DRIVE, depth=0.17)

# ---------------------------------------------------------------- 並木・街灯・消火栓・ベンチ
def along(line, step, start=0.0, end=None):
    end = line.length if end is None else end
    d = start
    out = []
    while d <= end + 1e-6:
        p = line.interpolate(d)
        out.append((p.x, p.y))
        d += step
    return out


prom_line = LineString(ISLAND_RAW.buffer(-PROM / 2, join_style='round', quad_segs=24).exterior.coords).intersection(PED.buffer(-0.12))
if isinstance(prom_line, MultiLineString):
    prom_line = max(prom_line.geoms, key=lambda g: g.length)
lamps = []
for (x, z) in along(prom_line, 0.62, 0.3):
    # 桟橋の付け根と橋台の前は空ける
    if -1.05 < x < 0.85 and z > 0.9:
        continue
    if abs(x - X_S2) < 0.6 and z > 0.9:
        continue
    lamps.append([round(x, 3), round(z, 3)])
ch = CITY_HALL
for (x, z) in [(0.15, -0.95), (1.75, -0.95), (0.15, 0.3), (1.75, 0.3)]:
    lamps.append([x, z])
for (x, z) in [(-3.15, 0.05), (-3.55, -2.75)]:
    lamps.append([x, z])

# 並木：区画の縁から少し内側の線に沿って
tree_rows = []
for b in blocks:
    if b.intersects(CITY_HALL.buffer(0.05)) or b.area < 0.3:
        continue
    edge = LineString(b.buffer(-0.075).exterior.coords)
    pts = along(edge, 0.48, 0.2)
    tree_rows.extend(pts)
trees = []
road_axes = [S1, S2_GRADE, A1]
for (x, z) in tree_rows:
    p = Point(x, z)
    # 交差点の近く・横断歩道・桟橋と橋台の前・建物の前は避ける
    if any(Point(c['c']).distance(p) < 0.36 for c in crosswalks):
        continue
    if p.within(BATTERY.buffer(0.15)):
        continue
    if Polygon([(-1.05, 0.6), (0.85, 0.6), (0.85, 1.5), (-1.05, 1.5)]).contains(p):
        continue
    if box(X_S2 - 0.55, 0.4, X_S2 + 0.55, 1.6).contains(p):
        continue
    trees.append([round(x, 3), round(z, 3), 0.2])
# 公園の木（市庁舎前の公園の縁と、バッテリー・パーク）
park_edge = LineString(CITY_HALL.buffer(-0.12).exterior.coords)
for (x, z) in along(park_edge, 0.42, 0.1):
    trees.append([round(x, 3), round(z, 3), 0.23])
bat = BATTERY.buffer(-0.12)
for g in getattr(bat, 'geoms', [bat]):
    for (x, z) in along(LineString(g.exterior.coords), 0.4, 0.15):
        trees.append([round(x, 3), round(z, 3), 0.23])
hydrants = [[X_S1 - W_STREET / 2 - 0.09, Z_A1 - W_DRIVE / 2 - 0.09, 0], [X_S1 + W_STREET / 2 + 0.09, Z_FDR - W_DRIVE / 2 - 0.09, 90],
            [X_S2 + W_STREET / 2 + 0.09, Z_A1 - W_DRIVE / 2 - 0.09, 0], [-2.55, Z_A1 + W_DRIVE / 2 + 0.09, 90],
            [3.0, Z_FDR - W_DRIVE / 2 - 0.09, 90], [0.4, Z_WSH + W_DRIVE / 2 + 0.09, 90], [4.6, Z_A1 + W_DRIVE / 2 + 0.09, 90]]
benches = [[0.85, -0.85, 0], [0.4, -0.38, 90], [1.3, -0.38, -90], [0.85, 0.12, 180],
           [-3.25, -0.4, 60], [-3.0, 0.2, 150], [-3.2, -2.3, 30], [0.2, Z_FRONT - 0.09, 180], [1.5, Z_FRONT - 0.09, 180]]

# ---------------------------------------------------------------- タクシー（右側通行の車線の上）
LANE = 0.105
cars = []


def car_on(line, d, lane, forward=True):
    p = line.interpolate(d)
    q = line.interpolate(min(line.length, d + 0.02)) if forward else line.interpolate(max(0, d - 0.02))
    dx, dz = q.x - p.x, q.y - p.y
    l = math.hypot(dx, dz) or 1
    dx, dz = dx / l, dz / l
    # 進む向きの右（上から見て時計回りに 90°）：(-dz, dx)
    rx, rz = -dz, dx
    cars.append([round(p.x + rx * lane, 3), round(p.y + rz * lane, 3), round(dx, 4), round(dz, 4)])


L_RING = RING.length
car_on(RING, 1.4, LANE, True)
car_on(RING, 4.1, LANE, False)
car_on(RING, L_RING * 0.42, LANE, True)
car_on(RING, L_RING * 0.6, LANE, False)
car_on(RING, L_RING - 3.0, LANE, True)
car_on(RING, L_RING - 0.9, LANE, False)
car_on(A1, 2.2, LANE, True)
car_on(A1, 5.0, LANE, False)
car_on(S1, 1.4, LANE * 0.9, True)
car_on(S2_GRADE, 0.8, LANE * 0.9, False)

# ---------------------------------------------------------------- 走行テスト（道の端が交差点か台座の縁で終わるか、水の上を走らないか）
def check():
    problems = []
    lines = {'waterfront': RING, 'avenue': A1, 'street-west': S1, 'street-bridge': S2_GRADE}
    for name, line in lines.items():
        if line.is_ring:
            continue
        for end in [Point(line.coords[0]), Point(line.coords[-1])]:
            at_edge = PED.exterior.distance(end) < 0.45 or not PED.contains(end)
            joins = [n for n, o in lines.items() if o is not line and o.distance(end) < 0.05]
            on_ramp = S2_RAMP.distance(end) < 0.05 and name == 'street-bridge'
            if not (at_edge or joins or on_ramp):
                problems.append(f'{name} の端 ({end.x:.2f}, {end.y:.2f}) が行き止まり')
    land = ISLAND.buffer(-0.05)
    if not PED.buffer(-0.2).contains(ISLAND):
        problems.append('島が台座の縁に近すぎる（まわりに水がない）')
    for name, line in lines.items():
        clipped = line.intersection(PED)
        water = clipped.difference(land)
        if water.length > 0.02:
            problems.append(f'{name} が水の上を {water.length:.2f} 走る')
    # 建物が道路・歩道・ほかの建物と重ならないか
    fps = []
    for b in buildings:
        p = b['parts'][0]
        s = p['size'] if isinstance(p['size'], list) else [p['size'], p['size']]
        fps.append((b['name'], box(p['c'][0] - s[0] / 2, p['c'][1] - s[1] / 2, p['c'][0] + s[0] / 2, p['c'][1] + s[1] / 2)))
    for name, f in fps:
        blk = [bk for bk in blocks if bk.intersects(f)]
        if not blk or not f.within(blk[0].buffer(-SIDEWALK + 0.005)):
            problems.append(f'建物 {name} が区画の歩道より外へ出ている')
        if f.intersects(CITY_HALL) or f.intersects(BATTERY):
            problems.append(f'建物 {name} が公園に重なる')
    for i in range(len(fps)):
        for j in range(i + 1, len(fps)):
            if fps[i][1].intersection(fps[j][1]).area > 1e-4:
                problems.append(f'建物 {fps[i][0]} と {fps[j][0]} が重なる')
    # 坂道の勾配と、海沿いの通りの上の高さ
    path = bridge['path']
    for a, b in zip(path, path[1:]):
        run = math.hypot(b[0] - a[0], b[1] - a[1])
        if run > 1e-6 and abs(b[2] - a[2]) / run > 0.16:
            problems.append(f'橋の路面の勾配 {abs(b[2] - a[2]) / run * 100:.0f}% が急すぎる')
    return problems


def poly_coords(p):
    return [[round(x, 4), round(z, 4)] for x, z in list(p.exterior.coords)[:-1]]


def multi_coords(g):
    return [poly_coords(h) for h in getattr(g, 'geoms', [g]) if h.area > 0.01]


layout = {
    'base': {'size': 10, 'cornerRadius': CORNER},
    'island': {'outline': poly_coords(ISLAND), 'front': Z_FRONT, 'back': Z_BACK},
    'roads': roads,
    'roadPolys': multi_coords(ROADS.intersection(PED_CUT)),
    'junctions': multi_coords(JUNCTIONS),
    'blocks': [poly_coords(b) for b in blocks],
    'parks': [{'name': p['name'], 'polys': multi_coords(p['poly']), **({'pond': p['pond']} if 'pond' in p else {}), **({'fort': p['fort']} if 'fort' in p else {})} for p in parks],
    'crosswalks': crosswalks,
    'buildings': buildings,
    'waterTanks': waterTanks,
    'bridge': bridge,
    'pier': pier,
    'ferry': ferry,
    'trees': trees,
    'lamps': lamps,
    'hydrants': [[round(a, 3), round(b, 3), c] for a, b, c in hydrants],
    'benches': benches,
    'cars': cars,
}


def fmt(L):
    lines = ['{']
    keys = list(L.keys())
    for ki, k in enumerate(keys):
        v = L[k]
        comma = ',' if ki < len(keys) - 1 else ''
        if k == 'buildings':
            lines.append(' "buildings": [')
            for bi, b in enumerate(v):
                head = {kk: vv for kk, vv in b.items() if kk != 'parts'}
                h = json.dumps(head, ensure_ascii=False)[:-1]
                lines.append(f'  {h}, "parts": [')
                for pi, q in enumerate(b['parts']):
                    lines.append('   ' + json.dumps(q, ensure_ascii=False) + (',' if pi < len(b['parts']) - 1 else ''))
                lines.append('  ]}' + (',' if bi < len(v) - 1 else ''))
            lines.append(' ]' + comma)
        elif isinstance(v, list):
            lines.append(f' "{k}": [')
            for i, it in enumerate(v):
                lines.append('  ' + json.dumps(it, ensure_ascii=False) + (',' if i < len(v) - 1 else ''))
            lines.append(' ]' + comma)
        else:
            lines.append(f' "{k}": ' + json.dumps(v, ensure_ascii=False) + comma)
    lines.append('}')
    return '\n'.join(lines) + '\n'


OUT.write_text(fmt(layout), encoding='utf-8')
probs = check()
print(f'layout.json: {len(blocks)} blocks, {len(buildings)} buildings, {len(trees)} trees, {len(lamps)} lamps, {len(crosswalks)} crosswalks, {len(cars)} cars')
print('走行テスト：問題なし' if not probs else '走行テスト：\n  ' + '\n  '.join(probs))

# ---------------------------------------------------------------- 上から見た図
if len(sys.argv) > 1:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.patches import Polygon as MPoly, Circle
    plt.rcParams['font.family'] = 'Noto Sans CJK JP'
    fig, ax = plt.subplots(figsize=(10, 10))
    ax.set_aspect('equal')
    ax.set_xlim(-5.3, 5.3)
    ax.set_ylim(5.3, -5.3)

    def fill(g, **kw):
        for h in getattr(g, 'geoms', [g]):
            ax.add_patch(MPoly(list(h.exterior.coords), closed=True, **kw))

    fill(PED, fc='#9fd0f2', ec='#a58c6a', lw=3)
    fill(ISLAND, fc='#e9e4dc', ec='#3b4a7a', lw=1.2)
    fill(ROADS.intersection(PED_CUT), fc='#6b6d7c', ec='none')
    for b in blocks:
        fill(b, fc='#f3e7da', ec='#c8b8a8', lw=0.6)
    fill(CITY_HALL, fc='#a9d46a', ec='none')
    fill(BATTERY, fc='#a9d46a', ec='none')
    for c in crosswalks:
        x, z = c['c']
        if c['dir'] == 'z':
            ax.add_patch(MPoly([(x - c['length'] / 2, z - c['depth'] / 2), (x + c['length'] / 2, z - c['depth'] / 2), (x + c['length'] / 2, z + c['depth'] / 2), (x - c['length'] / 2, z + c['depth'] / 2)], fc='white', ec='none'))
        else:
            ax.add_patch(MPoly([(x - c['depth'] / 2, z - c['length'] / 2), (x + c['depth'] / 2, z - c['length'] / 2), (x + c['depth'] / 2, z + c['length'] / 2), (x - c['depth'] / 2, z + c['length'] / 2)], fc='white', ec='none'))
    for b in buildings:
        p = b['parts'][0]
        s = p['size'] if isinstance(p['size'], list) else [p['size'], p['size']]
        top = max(q['y'][1] for q in b['parts'])
        ax.add_patch(MPoly([(p['c'][0] - s[0] / 2, p['c'][1] - s[1] / 2), (p['c'][0] + s[0] / 2, p['c'][1] - s[1] / 2), (p['c'][0] + s[0] / 2, p['c'][1] + s[1] / 2), (p['c'][0] - s[0] / 2, p['c'][1] + s[1] / 2)], fc='#c9a98a', ec='#6b5444', lw=0.6))
        ax.text(p['c'][0], p['c'][1], f"{b['name']}\n{top:.1f}", fontsize=6, ha='center', va='center')
    bp = bridge['path']
    ax.plot([p[0] for p in bp], [p[1] for p in bp], color='#d6b48c', lw=9, alpha=0.9)
    for p in bp:
        ax.text(p[0] + 0.15, p[1], f'{p[2]:.2f}', fontsize=7, color='#5a4028')
    ax.add_patch(Circle(bridge['tower']['at'], 0.2, color='#8a6a48'))
    d = pier['deck']
    ax.add_patch(MPoly([(d[0], d[2]), (d[1], d[2]), (d[1], d[3]), (d[0], d[3])], fc='#b59a80', ec='#6b5444'))
    s = pier['shed']
    ax.add_patch(MPoly([(s[0], s[2]), (s[1], s[2]), (s[1], s[3]), (s[0], s[3])], fc='#8fb9dc', ec='#3d5c7c'))
    for t in trees:
        ax.add_patch(Circle((t[0], t[1]), 0.08, color='#4c982a', alpha=0.8))
    for l in lamps:
        ax.add_patch(Circle((l[0], l[1]), 0.04, color='#333333'))
    for c in cars:
        ax.add_patch(Circle((c[0], c[1]), 0.06, color='#f2c230'))
        ax.annotate('', (c[0] + c[2] * 0.25, c[1] + c[3] * 0.25), (c[0], c[1]), arrowprops=dict(arrowstyle='->', color='#a07800'))
    hd = math.radians(ferry['heading'])
    ax.add_patch(MPoly([(ferry['c'][0] + math.sin(hd) * 0.95, ferry['c'][1] + math.cos(hd) * 0.95), (ferry['c'][0] - math.sin(hd) * 0.95 + math.cos(hd) * 0.28, ferry['c'][1] - math.cos(hd) * 0.95 - math.sin(hd) * 0.28), (ferry['c'][0] - math.sin(hd) * 0.95 - math.cos(hd) * 0.28, ferry['c'][1] - math.cos(hd) * 0.95 + math.sin(hd) * 0.28)], fc='white', ec='#2a4a8a'))
    ax.set_title('新しい配置（上から見た図。下が手前のカメラの側）')
    fig.tight_layout()
    fig.savefig(sys.argv[1], dpi=100)
    print('plan:', sys.argv[1])
